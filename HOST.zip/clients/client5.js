async function start() {
  var Slot_Num = 5;
  var token = await mdb.get(`token_slot_${Slot_Num}_get_`);
//  console.log(token)
  async function get_owner_(id) {
    if (id == await mdb.get(`${Slot_Num}_get_owner_id_`) || mdb.get(`get_devloper_id_`)) {
      return true;
    } else { return false; }
  }

  var text_status = await mdb.get(`text_status_get_${Slot_Num}_`),
    activity_type = await mdb.get(`activity_type_get_${Slot_Num}_`),
    activity_status = await mdb.get(`activity_status_get_${Slot_Num}_`);

  if (activity_type == null) var activity_type = 0;
  if (text_status == null) var text_status = "🇮🇳 | RK HOST | 🇮🇳";
  if (activity_status == null) var activity_status = 'idle';

  const client = new Discord.Client({
    fetchAllMembers: true,
    restTimeOffset: 0,
    failIfNotExists: false,
    shards: "auto",
    shardCount: 5,
    allowedMentions: {
      parse: ["roles", "users"],
      repliedUser: true,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER', 'MANAGE_MESSAGE', 'DIRECT_MESSAGE', Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction],
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
  });

  client.on("ready", (c) => {
    client.Slot_Num = Slot_Num;
    client.get_owner_ = get_owner_;
    client.commands = new Discord.Collection();
    client.aliases = new Discord.Collection();

    console.log(` \n✓ login as client: ${Slot_Num}`.blue.bold);

    const activities = { name: text_status, type: activity_type };

    client.user.setActivity(activities)
    console.log(activity_status)
    console.log(activities)
setTimeout(() => {
  try{
    client.user.setStatus(activity_status)
  }catch{}
}, 5000);
    var actiArray = [
      { name: text_status, type: activity_type }
    ];
    setTimeout(() => {
          client.user.setActivity(actiArray[0])  
    }, 5000);

    fs.readdirSync('./clients event').forEach((event) => {
      require(`../clients event/${event}`)(client)
    });
 //   require("../only mc .js")(client);
  })

  if (token !== null) {
    db.add("hosted_bot_count_", 1);
  }else{
    return;
  }

  client.login(token).catch(async e => {
    db.add("ofline_slot_", 1)
    console.log(`failed to login Number: ${Slot_Num}`.red)
    let ownerIdToSend = await mdb.get(`${Slot_Num}_get_owner_id_`);
    var email = await mdb.get(`_is_${ownerIdToSend}_email_veryfied_`);
  if(email !== null){
  console.log("ofline:  " + email)  
    }
  });
  mainClient.on("kill_", id => {
    if (id == Slot_Num) {
      client.destroy()
      db.add("ofline_slot_", 1)
    }
  })
   /* setInterval(() => {
    console.log(client.user)
  }, 5000);*/
}
start();

