const discord = require('discord.js');
const webhookClient = new discord.WebhookClient({ url: process.env["report_wh"] })
var {EmbedBuilder} = require("discord.js");



module.exports = {

 async log(text) {
   
  webhookClient.send({
	username: 'Report Log',
	avatarURL: icon,
	embeds: em,
}).catch({});
   
 },

  async error(text) {
    
webhookClient.send({
	username: 'Report Log',
	avatarURL: icon,
	embeds: em,
}).catch({});
    
  },

  async info(text) {
    
webhookClient.send({
	username: 'Report Log',
	avatarURL: icon,
	embeds: em,
}).catch({});
    
  },
  
}
