const { WebhookClient } = require('discord.js');

const webhookClient = new WebhookClient({ url: process.env["report_wh"] });
webhookClient.send({
	username: 'Report Log',
	avatarURL: icon,
	embeds: em,
}).catch({});