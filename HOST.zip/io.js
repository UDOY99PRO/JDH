var db = require ("quick.db");
var cook_cookie = require('cookie');

module.exports = (io) => {

io.on("connection", (socket) => {
  var code = cook_cookie.parse(socket.handshake.headers.cookie).Secret_tkn_;
  var details = db.get(`getDetails_${code}`);
var name = details.name, email = details.email, id = details.id;
var detailsObj = {
  name: name,
  email: email,
  id: id
}
  console.log(detailsObj);
  db.push("Chat_Messages_History_", `${true}:bot:@${detailsObj.name} joined the chat`)
socket.broadcast.emit("UserJoined_", { content: `@${detailsObj.name} joined the chat` })
  socket.emit("UserJoined_", { content: `message history will clear in every 24 hours` })
 /* let msg = {
    author: detailsObj.name,
    content: "hello there"
  }*/

  
socket.on("message_", (msg) => {
  var cnt = msg.content.replace(/>/g, "≥").replace(/</g, "≤")
  db.push("Chat_Messages_History_", `${false}:${details.name}:${cnt}`)
var nmsg = {
  content: cnt,
  author: details.name
}

socket.broadcast.emit("message_", nmsg)

})

socket.on("botMessage_", (msg) => {
    db.push("Chat_Messages_History_", `${true}:bot:${msg.content}`)
})
  
  socket.on("MessageHistory_Give_", () => {
var messageArray = db.get("Chat_Messages_History_");
  if(messageArray !== null){
  messageArray.forEach(m => {
    var args = m.split(':');
 //   console.log(args[0])
    var botTF = args[0];
    var author = args[1];
    var content = args.slice(2).join(':');
    if(botTF == "true"){
     var ping = new RegExp(`@${detailsObj.name}`,"g");
      var tmsg = {
          ms: {
  bot: true,
  me: false,
  other: false,
  author: author,
  content: content.replace(ping, "you")
  }
      }
      console.log(tmsg)
   socket.emit("MessageHistory_Take_", tmsg);
     // return;
    }
    if(botTF == "false"){
      if(author == details.name){
        var tmsg = {
            ms: {
  bot: false,
  me: true,
  other: false,
  author: author,
  content: content
  }
        }
        console.log(tmsg)
           socket.emit("MessageHistory_Take_", tmsg);
    //  return;
        
      }else{
      var tmsg = {
         ms: {
  bot: false,
  me: false,
  other: true,
  author: author,
  content: content
                       } 
      }
           socket.emit("MessageHistory_Take_", tmsg);
     // return;
      }
    }
 //   console.log(tmsg)
 //   socket.emit("MessageHistory_Take_", tmsg)
  });
  }
  });
socket.on("disconnect", () => {
    db.push("Chat_Messages_History_", `${true}:bot:@${detailsObj.name} left the chat`)
  socket.broadcast.emit("UserLeft_", { content: `@${detailsObj.name} left the chat` });
});
});


};
