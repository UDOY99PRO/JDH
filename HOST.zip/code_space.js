async function start(){
  var Slot_Num = 1;
var token  = await mdb.get(`token_slot_${Slot_Num}_get_`);
async function get_owner_(id) {
 if(id == await mdb.get(`${Slot_Num}_get_owner_id_`) || mdb.get(`get_devloper_id_`)){
   return true;
 } else { return false; }
}
var prefix = 1 //await mdb.get(`get_prefix_${Slot_Num}_`)
  mdb.set(`get_prefix_${Slot_Num}_`, 1)
  var text_status = await mdb.get(`text_status_get_${Slot_Num}_`),
    activity_type = await mdb.get(`activity_type_get_${Slot_Num}_`),
    activity_status = await mdb.get(`activity_status_get_${Slot_Num}_`);

  if(prefix == null) var prefix = '1';
  if(activity_type == null) var activity_type = 1;
  if(text_status == null) var text_status = "🇮🇳 | RK HOST | 🇮🇳";
  if(activity_status == null) var activity_status = 'idle';
  
const client = new Discord.Client({
    fetchAllMembers: true,
    restTimeOffset: 0,
    failIfNotExists: false,
    shards: "auto",
    shardCount: 5,
    allowedMentions: {
      parse: ["roles", "users"],
      repliedUser: true,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER', 'MANAGE_MESSAGE', 'DIRECT_MESSAGE', Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction],
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
});

  client.on("ready", (c)=> {
  client.Slot_Num = Slot_Num;
    //client.destroy().then(v => db.subtract("ofline_slot_", 1));
      client.commands = new Discord.Collection();
  client.aliases = new Discord.Collection();
    
console.log(` \n✓ login as client: ${Slot_Num}`.blue.bold);

const activities = { name: text_status, type: activity_type };    

      client.user.setActivity(activities)
     
      client.user.setStatus(activity_status)
    
      fs.readdirSync('./clients event').forEach((event) => {
      require(`../clients event/${event}`)(client)
    });
               })
  client.on("messageCreate", async(message) => {
    if(message.content.startsWith(prefix)){
      const args = message.content.slice(prefix.length).trim().split(/ +/g);
       const cmd = args.shift().toLowerCase();
       
      if(cmd == "help" || cmd == "h"){
var help = new Discord.EmbedBuilder().setColor("Random").setTitle("Help menu")
        .setTimestamp();
        message.reply({embeds: [help]});
      } else if(cmd == 'react'){
      message.react("👋")
  } else if(cmd == "kick"){
     if(!args[0]){
        message.reply("Give me a user to kick!").then(m => {
          setTimeout(m.delete, 5000);
          
        }) 
          return;
      }
        message.reply(`${args[0]} kicked`)
    } else if(!message.content.startsWith(prefix)) return;
 }
    });

  
if(token !== null){
  db.add("hosted_bot_count_", 1);
}
  
client.login(token).catch(e => {
  db.add("ofline_slot_", 1)
  console.log(`failed to login Number: ${Slot_Num}`.red)
});
mainClient.on("kill_", id => {
  if(id == Slot_Num){
    client.destroy()
    db.add("ofline_slot_", 1)
            }
})
}
start();
