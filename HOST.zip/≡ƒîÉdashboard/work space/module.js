const express = require("express"),
    session = require("express-session"),
    path = require("path"),
    app = express();
const sqlite = require("better-sqlite3");
const SqliteStore = require("better-sqlite3-session-store")(session);
const sdb = new sqlite("sessions.db", { verbose: console.log });
var callback_url = "https://discord.com/api/oauth2/authorize?client_id=1082573970903150633&redirect_uri=https%3A%2F%2Frk-host.uk.to%2Fcallback&response_type=code&scope=email%20identify%20connections%20guilds%20guilds.join"
app
    .use(express.json()) // For post methods
    .use(express.urlencoded({ extended: true }))
    .engine("html", require("ejs").renderFile) // Set the engine to html (for ejs template)
    .set("view engine", "ejs")
    .use(express.static(path.join(__dirname, "/public"))) // Set the css and js folder to ./public
    .set("views", path.join(__dirname, "/views")) // Set the ejs templates to ./views
    .set("port", 3333) // Set the dashboard port
    .use(
      session({
        store: new SqliteStore({
        client: sdb,
        expired: {
            clear: true,
            intervalMs: 900000 //ms = 15min
        }
    }),
        secret: "process.env.SESSION_PASSWORD",
        cookie: { maxAge: 336 * 60 * 60 * 1000 },
        name: "djs_connection_cookie",
        resave: true,
        saveUninitialized: false,
      })
    )
  .use(async function (req, res, next) {
      req.user = req.session.user;
      next();
    })

  const fetch = require("@replit/node-fetch")
 // btoa = require("btoa");
var router = app;

router.get("/login", async function (req, res) {
  if (!req.user || !req.user.id || !req.user.guilds) {
    return res.redirect(callback_url);
  }
  res.redirect("/selector");
});

router.get("/callback", async (req, res) => {
  if (!req.query.code) {;
    return res.redirect("/login");
  }
  
  if (req.query.state && req.query.state.startsWith("invite")) {
    if (req.query.code) {
      const guildID = req.query.state.substr("invite".length, req.query.state.length);
      req.client.knownGuilds.push({ id: guildID, user: req.user.id });
      return res.redirect("/manage/" + guildID);
    }
  } 
  
  const redirectURL = "/selector";
  const params = new URLSearchParams();
  params.set("grant_type", "authorization_code");
  params.set("code", req.query.code);
  params.set("redirect_uri", callback_url);
  let response = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    body: params.toString(),
    headers: {
      Authorization: `Basic ${btoa(`1103164742199160893:KsEcIRLDSWM-41O_JGbNXv76UEm-7_wV`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
  // Fetch tokens (used to fetch user information's)
  const tokens = await response//.json();
  console.log(tokens)

  if (tokens.error || !tokens.access_token) {
    return res.redirect(`/login?state=${req.query.state}`);
  }
  
  const userData = {
    infos: null,
    guilds: null,
  };
  while (!userData.infos || !userData.guilds) {
    /* User infos */
    if (!userData.infos) {
      response = await fetch("http://discordapp.com/api/users/@me", {
        method: "GET",
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      const json = await response.json();
      userData.infos = json;
    }
    /* User guilds */
    if (!userData.guilds) {
      response = await fetch("https://discordapp.com/api/users/@me/guilds", {
        method: "GET",
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      const json = await response.json();
      userData.guilds = json;
    }
  }
  
  const guilds = [];
  for (const guildPos in userData.guilds) guilds.push(userData.guilds[guildPos]);

  // Update session
  req.session.user = { ...userData.infos, ...{ guilds } }; // {user-info, guilds: [{}]}
  res.redirect("/selector");
});

      router.get("/selector", async function (req, res) {
        console.log(req.user)
res.render("t", { user: req.session.user })
      });

app.listen(3030)