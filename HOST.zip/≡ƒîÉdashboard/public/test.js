self.addEventListener('push', event => {
  const notificationData = event;
var data = event.data.json()
  const options = data.options;
  
  /*{
    body: data.body,
    icon: 'https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png',
    badge: 'https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png',
    actions: [
        { action: 'reply', title: 'Reply' },
    ],
  };*/

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener(
  "notificationclick",
  (event) => {
   if (event.action === "close") { 
    event.notification.close();
   }else if(event.action === "reply"){
     var wss = new WebSocket("wss://rk-host.uk.to/");
     wss.send(event)
   }
  /*  if (event.action === "archive") {
      // User selected the Archive action.
      archiveEmail();
    } else {
      // User selected (e.g., clicked in) the main body of notification.
      clients.openWindow("/inbox");
    }*/
  },
  false,
);

var CACHE_NAME = 'my-site-cache-v1';
var urlsToCache = [
'/'
];

self.addEventListener('install', function(event) {
// Perform install steps
 event.waitUntil(
  caches.open(CACHE_NAME)
   .then(function(cache) {
   console.log('Opened cache');
    return cache.addAll(urlsToCache);
 })
 );
});

self.addEventListener('fetch', function(event) {
 event.respondWith(
 caches.match(event.request)
 .then(function(response) {
  // Cache hit - return response
   if (response) {
   return response;
   }
   return fetch(event.request);
    }
   )
  );
});