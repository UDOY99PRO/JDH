window.addEventListener('click', function(event) {
        // Check if the event target is the button
        if (event.target === button) {
          console.log(event)
        }