self.addEventListener('push', event => {
  const notificationData = event;

  const options = {
    body: "helloe",
    icon: 'https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png',
    badge: 'https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png', // Specify the correct path to your badge icon
  };

  event.waitUntil(
    self.registration.showNotification("Chat Notification", options)
  );
});