var server_name_will = document.getElementById("server_name_will");
var nameError = document.getElementById("nameError");
var selectError = document.getElementById("selectError");
var dropdown = document.getElementById("dropdown");
var CreateServerFinalBtn = document.getElementById("CreateServerFinalBtn");
server_name_will.addEventListener("input", function(){
    DoChangeButton();
    server_name_will.value = server_name_will.value.replace(/\ /g, "_");
if(!server_name_will.value){
   nameError.innerHTML = "Name Is Required!";
  server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
 }else if(server_name_will.value.split('').length < 3){
   nameError.innerHTML = "The name should have three characters or more."
    server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
 }else if(server_name_will.value.split('').length > 6){
   nameError.innerHTML = "The name should have six characters or fewer."
    server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
 }else{
   nameError.innerHTML = ""
    server_name_will.style.border = '1px solid #27f207';
    server_name_will.style.boxShadow = 'rgba(7, 242, 58, 200) 0px 0px 20px 0px';
DoChangeButton();
 }
  });
    dropdown.addEventListener("focusout", function(){
      if(dropdown.value == "defval"){
    selectError.innerHTML = "Select A Value First.";
     dropdown.style.border = '1px solid #f20707';
    dropdown.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
        DoChangeButton();
      }else{
        selectError.innerHTML = "";
    dropdown.style.border = '1px solid #27f207';
    dropdown.style.boxShadow = 'rgba(7, 242, 58, 200) 0px 0px 20px 0px';
        DoChangeButton();
      };
    });
      dropdown.addEventListener("change", function(){
if(dropdown.value !== "defval"){
  selectError.innerHTML = "";
      dropdown.style.border = '1px solid #27f207';
    dropdown.style.boxShadow = 'rgba(7, 242, 58, 200) 0px 0px 20px 0px';
DoChangeButton();
}});

  function csc(){
  if(!server_name_will.value){
   nameError.innerHTML = "Name Is Required!";
  server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
    return;
}else if(server_name_will.value.split('').length < 3){
      nameError.innerHTML = "The name should have three characters or more."
    server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
    return;
  }else if(server_name_will.value.split('').length > 6){
     nameError.innerHTML = "The name should have six characters or fewer."
    server_name_will.style.border = '1px solid #f20707';
    server_name_will.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
return;
  }else if(dropdown.value == "defval"){
        selectError.innerHTML = "Select A Value First.";
     dropdown.style.border = '1px solid #f20707';
    dropdown.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
    return;
  }else{
    
  }
};

  function DoChangeButton() {
  if(dropdown.value !== "defval"){
 if(server_name_will.value.split('').length >= 3 && server_name_will.value.split('').length <= 6){
   CreateServerFinalBtn.style.boxShadow = 'rgba(7, 242, 58, 200) 0px 0px 20px 0px';
     }else{
CreateServerFinalBtn.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
 }
  }else{
    CreateServerFinalBtn.style.boxShadow = 'rgba(247, 0, 16, 200) 0px 0px 20px 0px';
  }
     