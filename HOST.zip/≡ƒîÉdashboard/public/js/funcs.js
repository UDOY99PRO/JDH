if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('https://rk-host.uk.to/service-worker.js') 
        .then((reg) => { 
          setInterval(() => {
            console.log('Service worker registered.', reg); 
          }, 1000);
        }); 
    });
}
