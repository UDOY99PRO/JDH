async function querypost(url, query){
await fetch("toolPage/smsBomb", {
    method: "POST",
})
 .then(await ressponse => {
   return response;
 })
