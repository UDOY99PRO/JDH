
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      navigator.serviceWorker.register('notification-worker.js')
        .then(async registration => {
          const permission = await window.Notification.requestPermission();
          if (permission === 'granted') {
            console.log('Notification permission granted.');
          } else {
            console.log('Notification permission denied.');
          }
        })
        .catch(error => {
          console.error('Service Worker registration failed:', error);
        });
    }
