//setTimeout(() => {
document.getElementById("settingPanel").hidden = true;
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const socket = io("/chat");

   let messageArea = document.querySelector('#messageArea');

function scrollToBottom() {
  //if(autoscroll)
 // setTimeout(() => {
  //  messageArea.scrollTop = messageArea.scrollHeight;
  const container = document.querySelector('#messageArea');
  container.scrollTop = container.scrollHeight - container.clientHeight;

 // }, 5000);
      }
function giveMyTime(ms){
  if(!ms) return 0;
var targetTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
var date = new Date(ms);
var formatter = new Intl.DateTimeFormat('en-US', {
  timeZone: targetTimezone,
  weekday: 'long',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
});

var formattedDate = formatter.format(date);
return formattedDate;
}
  setTimeout(() => {
scrollToBottom()
  }, 3000)
let incomming_message_template = `<div class="bg-indigo-500 text-black rounded-lg ml-2 float-left clear-both w-3/4 border-b-4"><img onclick=showProfile(<%%id%%>n)}) class="rounded-lg float-left" src=<%%avatar%%> width="40" hight="40"><h1 class="text-gray-100 float-left ml-4"><%%author%%></h1><br><div class="border rounded-lg border-zinc-300"><p class="ml-2 m-2"><%%message%%></p></div><p style="font-size: 10px; margin-right: 5px;" class="float-right clear-both"><%%timestamp%%></p></div>`,
bot_message_template = `<div class="bg-gradient-to-r from-pink-500 via-sky-500 to-emerald-500 text-black rounded-lg ml-2 float-left clear-both w-3/4 border-b-4" id="bott"><img onclick=showProfile(${0000}) class="rounded-lg float-left" src="https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png" width="40" hight="40"><h1 class="text-gray-100 float-left ml-4">BOT 🤖 ✓</h1><br><div class="border rounded-lg border-zinc-300"><p class="ml-2 m-2"><%%message%%></p></div><p style="font-size: 10px; margin-right: 5px;" class="float-right clear-both"><%%timestamp%%></p></div>`,
  outgoing_message_template = `<div class="bg-purple-500 text-black rounded-lg mr-2 float-right clear-both w-3/4 border-b-4"><img onclick=showProfile(<%%id%%>n) class="rounded-lg float-left" src="<%%avatar%%>" width="40" hight="40"><h1 class="text-gray-100 float-right mr-4">you</h1><br><div class="border rounded-lg border-zinc-300"><p class="mr-2 m-2 float-right"><%%message%%></p></div><p style="font-size: 10px; margin-right: 5px;" class="float-right clear-both"><%%timestamp%%></p></div>`

/** 
<div class="bg-purple-500 text-black rounded-lg mr-2 float-right clear-both w-3/4 border-b-4">
  <img onclick="showProfile(<%%id%%>n)" class="rounded-lg float-left" src="<%%avatar%%>" width="40" height="40">
  <h1 class="text-gray-100 float-right mr-4">you</h1><br>
  <div class="border rounded-lg border-zinc-300">
    <p class="mr-2 m-2 float-right"><%%message%%></p>
  </div>
  <p><%%time%%></p> <a q!-- Placeholder for time -->
</div>
*/
socket.on("message_", (data) => {
  if(data.id == id){
  messageArea.innerHTML += outgoing_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, data.avatar).replace(/<%%id%%>/g, data.id).replace(/<%%timestamp%%>/g, giveMyTime(Date.now()));
  scrollToBottom()    
  }else{
 messageArea.innerHTML += incomming_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, data.avatar).replace(/<%%id%%>/g, data.id).replace(/<%%author%%>/g, data.name).replace(/<%%timestamp%%>/g, giveMyTime(Date.now()));
  scrollToBottom()  
  }
})
{
  let len = 0;
   fetch("https://rk-host.uk.to/api/json/chat/message/history").then(data => data.json()).then(sorted => sorted.sort((a, b) => a.timestamp - b.timestamp)).then(history => {
     for(i=0; i<history.length; i++){
    if(i == history.length){
        scrollToBottom();
      }
       var data = history[i];
       if(data.bot == false){
      if(data.id == id){
  messageArea.innerHTML += outgoing_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, avatar).replace(/<%%id%%>/g, data.id).replace(/<%%timestamp%%>/g, giveMyTime(data.timestamp));
//  scrollToBottom()    
      }else{
        u = incomming_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, data.avatar).replace(/<%%id%%>/g, data.id).replace(/<%%author%%>/g, data.name).replace(/<%%timestamp%%>/g, giveMyTime(data.timestamp));
 messageArea.innerHTML += u;
//  scrollToBottom()  
    }
         }else{
    messageArea.innerHTML += bot_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%timestamp%%>/g, giveMyTime(data.timestamp));
 // scrollToBottom()    
       }
     }
   /* history.forEach(data => {
      if(len == history.length){
        scrollToBottom();
      }
      len++;
       if(data.bot == false){
      if(data.id == id){
  messageArea.innerHTML += outgoing_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, avatar).replace(/<%%id%%>/g, data.id);
//  scrollToBottom()    
      }else{
        u = incomming_message_template.replace(/<%%message%%>/g, data.message).replace(/<%%avatar%%>/g, data.avatar).replace(/<%%id%%>/g, data.id).replace(/<%%author%%>/g, data.name);
 messageArea.innerHTML += u;
//  scrollToBottom()  
    }
         }else{
    messageArea.innerHTML += bot_message_template.replace(/<%%message%%>/g, data.message);
 // scrollToBottom()    
       }
    })*/
   
                                                                                       });
}

async function send(){
      document.getElementById("msg").focus();
  var msg = document.getElementById("msg").value;
document.getElementById("msg").value = "";
if(!msg){
  const element = document.getElementById("msg");
element.classList.remove("border-green-500");
  element.classList.add("border-red-500");
  element.placeholder = "Write Somthing!";
 showToast()
  setTimeout(() => {
    element.classList.remove("border-red-500");
element.classList.add("border-green-500");
      element.placeholder = "Hii";
  }, 3000);

  return;
}
messageArea = document.querySelector('#messageArea');
   // let mainDiv = document.createElement('div')

     await socket.emit("ChatMessage_", {message: msg}, async(idCallback) => {
var msg2 = msg.replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt");
  var hypelink = /\[(.*?)\]\((.*?)\)/;
  var matchR = msg2.match(hypelink);
if(matchR){
  console.log(matchR)
  messageArea.innerHTML += outgoing_message_template.replace(/<%%message%%>/g, msg2).replace(/<%%avatar%%>/g, avatar).replace(/<%%id%%>/g, id).replace(/<%%timestamp%%>/g, giveMyTime(Date.now()));
  scrollToBottom()
    document.getElementById("msg").focus();
}else{
  messageArea.innerHTML += outgoing_message_template.replace(/<%%message%%>/g, msg2).replace(/<%%avatar%%>/g, avatar).replace(/<%%id%%>/g, id).replace(/<%%timestamp%%>/g, giveMyTime(Date.now()));
  scrollToBottom()
  document.getElementById("msg").focus();
}
      })
}

//user left and joined event
{
socket.on("UserJoined_", async(data) => {
  if(data.id == id){return;}   messageArea.innerHTML += bot_message_template.replace(/<%%message%%>/g, `${data.name} Joined The Chat <br> Say Hii To @${data.name}!`);
  scrollToBottom() 
});
socket.on("UserLeft_", async(data) => {
    if(data.id == id){return;}
    messageArea.innerHTML += bot_message_template.replace(/<%%message%%>/g, `${data.name} Left The Chat!`);
  scrollToBottom() 
}); 
}


  function openSettings() {
    var panel = document.getElementById("settingPanel");
    if(panel.hidden === true){
      panel.hidden = false    
    }else{
    panel.hidden = true
  }
  }

function reset(){
      document.getElementById("msg").classList.remove("border-red-500");
document.getElementById("msg").classList.add("border-green-500");
      document.getElementById("msg").placeholder = "Hii";
        
}

function showToast(){
   var toastContainer = document.getElementById('toast-container');
    toastContainer.innerHTML = '<span style="color:red;">Please Write A Message To Send!</span>';
    toastContainer.style.display = 'block';

    setTimeout(function() {
        toastContainer.style.display = 'none';
    }, 3000);
}

function showProfile(log){
fetch(`https://rk-host.uk.to/api/json/profile/user/get/${(log)}`).then(data => data.json()).then(res =>{
     var toastContainer = document.getElementById('toast-container');
    toastContainer.innerHTML = `<span style="color:white;">Viewing ${res.name} ' Profile, <br>
    He/She Sends ${res.messages.length} messages,<br>
  His/Her id is: ${log}</span>`;
    toastContainer.style.display = 'block';

    setTimeout(function() {
        toastContainer.style.display = 'none';
    }, 7000);
})
}
//852183674203144226

/*
const text = "[me1](me2)";
const regex = /\[(.*?)\]\((.*?)\)/;

const matches = text.match(regex);
if (matches) {
    const me1 = matches[1]; // Captured text between [ and ]
    const me2 = matches[2]; // Captured text between ( and )
    
    console.log(me1, me2);
}
*/
//}, 7000);

  function getPing(){
    const start = Date.now();

  socket.emit("ping", () => {
    const duration = Date.now() - start;
    document.getElementById("ping").innerHTML = duration;
    if(duration < 6e2){
     document.getElementById("img").innerHTML = "<img src='https://cdn.discordapp.com/emojis/1093815117663195267.png' width='20' hight='20'>"; 
    }else{
document.getElementById("img").innerHTML = "<img src='https://cdn.discordapp.com/emojis/1093815821257670708.png' width='20' hight='20'>";
                            }
    console.log(duration);
  });
  }
  getPing()
  setInterval(() => {
  getPing()
}, 5000); 