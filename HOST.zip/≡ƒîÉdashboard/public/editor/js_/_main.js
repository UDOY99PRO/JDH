window.onload = async function() {
//setTimeout(async() => {
   async function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
  }
//var loadingMessage = document.getElementById("loading_message");
function updateMsg(msg){
  document.getElementById("loading_message").innerHTML = msg
}
function closeLoading(){
  document.getElementById("loader_div").style.display = "none";
}

var editor = ace.edit("editor");
 editor.session.setMode("ace/mode/html");
  /*setTimeout(() => {  document.getElementById("loader_div").style.display = "none";
  }, 5000)*/
ace.require("ace/ext/language_tools")
  editor.setOptions({
  enableSnippets: true,
  enableLiveAutocompletion: true,
 enableBasicAutocompletion: true,
  });
editor.getSession().setUseWrapMode(true)
 editor.setOption("cursorStyle", "smooth-slim");
  updateMsg("Getting Saved Codes...");
   await sleep(1000);
fetch("https://rk-host.uk.to/code/api/web/code").then(response => response.json()).then(async res => {
    editor.setValue(res.code);
      editor.clearSelection();
  //await sleep(3000);
  updateMsg("Adding Beauty To Your Codes...");
  await sleep(2000);
  }).catch(error => {
console.error(error)
  });
function save() {
    fetch("https://rk-host.uk.to/code/api/web/code", {
  method: "post",
  headers: {
    'Content-Type': 'application/json' // Specify JSON content type
  },
  body: JSON.stringify({
    code: editor.getValue()
  })
})
  .then(response => response.json()).then(res => {
  //  alert(res)
   alert(res.success ? `Document Saved Successfully` : "Failed To Save Document"); 
  })
  .catch(error => {});
}
//  setInterval(save, 5000);
document.getElementById("saveBTN").addEventListener("click", save);
window.addEventListener('beforeunload', function(event) {
  save();
  event.preventDefault();
  event.returnValue = '';
});
   await sleep(1000);
  updateMsg("Done ✓");
await sleep(1000);
  closeLoading();
        function openPreview() {
      console.log("clicked")
          document.getElementById("div_editor").style.display = "none";
      document.getElementById("div_settings").style.display = "none";
     document.getElementById("div_control").style.display = "none";
      document.getElementById("div_preview").style.display = "block";

    var iframe = document.getElementById("pre_frame");
    var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
const iframeWindow = iframe.contentWindow || iframe.contentDocument.defaultView; 
  iframeDoc.open();
    iframeDoc.write(editor.getValue());
    iframeDoc.close();
    }
/*}, 0);*/
document.getElementById("openPre").addEventListener("click", openPreview);  
}