module.exports = async function(req, res){
    let cc = req.query.state;
  if(!cc){
    cc = "/"
  }
if (!req.query.code) {
    return res.redirect(`https://rk-host.uk.to/login?state=${cc}`);
  }

console.log(req.query)
 /* if (req.query.state && req.query.state.startsWith("invite")) {
    if (req.query.code) {
      const guildID = req.query.state.substr("invite".length, req.query.state.length);
      req.client.knownGuilds.push({ id: guildID, user: req.user.id });
      return res.redirect("/manage/" + guildID);
    }
  } */
  
  const redirectURL = "/";
  const params = new URLSearchParams();
  params.set("grant_type", "authorization_code");
  params.set("code", req.query.code);
  params.set("redirect_uri", `https://rk-host.uk.to/callback`);
  let response = await fetch("https://discord.com/api/oauth2/token", {
    method: "POST",
    body: params.toString(),
    headers: {
      Authorization: `Basic ${btoa(`1082573970903150633:DqxkDLxSdLyi-aX2TGJXq4rr_3OS-MBG`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
  // Fetch tokens (used to fetch user information's)
  const tokens = await response.json();
  // If the code isn't valid
  if (tokens.error || !tokens.access_token) {
    return res.redirect(`/login?state=${req.query.state}`);
  }
  
  const userData = {
    infos: null,
    guilds: null,
  };
  while (!userData.infos || !userData.guilds) {
    /* User infos */
    if (!userData.infos) {
      response = await fetch("http://discordapp.com/api/users/@me", {
        method: "GET",
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      const json = await response.json();
      userData.infos = json;
    }
    /* User guilds */
    if (!userData.guilds) {
      response = await fetch("https://discordapp.com/api/users/@me/guilds", {
        method: "GET",
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      const json = await response.json();
      userData.guilds = json;
    }
  }

  const guilds = [];
  for (const guildPos in userData.guilds) guilds.push(userData.guilds[guildPos]);

  // Update session
  req.session.user = { ...userData.infos, ...{ guilds } }; // {user-info, guilds: [{}]}
  console.log(req.session.user)
  res.redirect(cc);
  if(req.session.user.email){
  if(!(await mdb.get(`_is_${req.session.user.id}_email_veryfied_`))){
    await mdb.set(`_is_${req.session.user.id}_email_veryfied_`, req.session.user.email)
  }else{
    return;
  }
}else{
    return;
  }
}