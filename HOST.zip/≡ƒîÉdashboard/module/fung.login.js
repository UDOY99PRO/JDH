module.exports = async function(req, res){
  
if (!req.user || !req.user.id || !req.user.guilds) {
    return res.redirect(
      `https://discord.com/api/oauth2/authorize?client_id=1082573970903150633&redirect_uri=${encodeURIComponent("https://rk-host.uk.to/callback"
      )}&response_type=code&scope=identify%20email%20guilds%20guilds.join&state=${req.query.state || "no"}`
    );
  }
  res.redirect("/selector");

}

//https://discord.com/api/oauth2/authorize?client_id=1082573970903150633&redirect_uri=https%3A%2F%2Frk-host.uk.to%2Fcallback&response_type=code&scope=identify%20email%20guilds%20guilds.join