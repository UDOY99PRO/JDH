module.exports = async function(req, res, next){
if (!req.user || !req.user.id || !req.user.guilds) {
  return res.redirect(`/login?state=${req.originalUrl}`);
}
next();
};