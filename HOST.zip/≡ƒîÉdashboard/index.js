const express = require("express"),
   WebSocket = require('ws'),
   bodyParser = require('body-parser'),
    session = require("express-session"),
  apiRoute = require("./routes/api"),
  CodeApiRoute = require("./routes/code"), 
  gameRoute = require("./routes/games"),
  callback = require("./module/fung.callback.js"),
  login = require("./module/fung.login.js"),
  checkAuth = require("./module/check.auth.js"),
  PanelRoute = require("./routes/panel"),
    EmailVerify = require("./routes/EmailVerify"),
    path = require("path"),
    app = express();
const socketIOSession = require("socket.io-express-session");
const server = app.listen(3030);
const io = require('socket.io')(server, {
});
const webPush = require('web-push');
var keys = {"publicKey":"BHYKejA7pAjIQOrVoaA7hA6Hf3bIXbXhrOBSYKhxqLr4TuJp2e1Qo3-fA0NhuqnQXsGjD_hAt2FPcniXoWmeeuM","privateKey":"KN0UOwJWnssbEmRlOO8L2VgBiNPmM54PVldUonkWwEY"}
const publicKey = keys.publicKey; // Your VAPID public key
const privateKey = keys.privateKey; // Your VAPID private key
webPush.setVapidDetails('mailto: rkhost789@gmail.com', publicKey, privateKey);

const sqlite = require("better-sqlite3");
const SqliteStore = require("better-sqlite3-session-store")(session);
const sdb = new sqlite("sessions.db", { verbose: console.log });

    var sessionMDWR = session({
        store: new SqliteStore({
        client: sdb,
        expired: {
            clear: true,
            intervalMs: 900000 //ms = 15min
        }
    }),
        secret: "process.env.SESSION_PASSWORD",
        cookie: { maxAge: 336 * 60 * 60 * 1000 },
        name: "djs_connection_cookie",
        resave: true,
        saveUninitialized: false,
      })

app
   .use(express.json()) // For post methods
    .use(express.urlencoded({ extended: true }))
  .use(bodyParser.urlencoded({ extended: true }))

    .engine("html", require("ejs").renderFile) // Set the engine to html (for ejs template)
    .set("view engine", "ejs")
    .use(express.static(path.join(__dirname, "/public"))) // Set the css and js folder to ./public
    .set("views", path.join(__dirname, "/views")) // Set the ejs templates to ./views
    .set("port", 3333) // Set the dashboard port
    .use(sessionMDWR)
  .use(async function (req, res, next) {
    if(req.session){
      req.user = req.session.user; 
      return next();
    }
      next();
    })

io.use(socketIOSession(sessionMDWR))
var expressWs = require('express-ws')(app);

const chatIO = require('./sockets/chat.io.js');
chatIO(io, socketIOSession(sessionMDWR));

  const fetch = require("node-fetch");
app.get('/', (req, res) => {
  const clientURL = req.protocol + '://' + req.get('host') + req.originalUrl;
  console.log('Client URL:', clientURL);
  const referer = req.get('referer');
    if (referer) {
        console.log(`Client came from: ${referer}`);
    } else {
        console.log('Client did not come from a specific website.');
    }
  res.send('Hello, world!');
});
app.get("/ws", async(req, res) => {
res.render("socket ping");
});
//hosted webs route
app.get("/w", (req, res) => {
res.send("Please include web id")
})
app.get("/w/:id", async(req, res) => {
var WebKey = await codeDB.get(`html_code_website_.key=${req.params.id}`);
  if(!WebKey){
    return res.send(`No web found with this id: ${req.params.id}`)
  }
var WebKeyArr = WebKey.split("<%=%>");
  res.send(await codeDB.get(WebKeyArr[0]));
  var vws = WebKeyArr[1];
  await codeDB.set(`html_code_website_.key=${req.params.id}`, `${WebKeyArr[0]}<%=%>${WebKeyArr[1] + 1}`);
})



app.get("/chat", async(req, res, next) => {
  res.locals.icon = 'https://cdn.discordapp.com/avatars/1082573970903150633/de5c8eee42a4e61892be37f230275f3e.png';
   checkAuth(req, res, next)
res.render("pages/💬chat.ejs", {
  name: req.user.username,
  avatar: `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png`,
req: req.user,
  id: req.user.id,
});
 // console.log(req.user)
});
app.get("/login", (req, res) => {
  const referer = req.get('referer');
    if (referer) {
        console.log(`Client came from: ${referer}`);
    } else {
        console.log('Client did not come from a specific website.');
    }
  if(req.query.state){
    var state = req.query.state;
    var title = (req.query.state).replace(/\//g, "|");
  }else{
    var state = "/";
    var title = "*";
  }
res.render("pages/login", {
state: state,
title: title,
})
})
app.get("/auth/login", async function (req, res) {
  login(req, res);
});

app.get("/callback", async (req, res, next) => {
callback(req, res);
});

      app.get("/selector", checkAuth, async function (req, res) {
        res.render("selector", {
user: req.user,
                                       Perm: discord.PermissionsBitField,
          client: mainClient
        })
//res.render("t", { user: req.user })
      });
app.get("/web/panel/v1", checkAuth, async(req, res) => {
res.render("pages/web host/web panel", {
req: req,
  name: req.user.username,
  avatar: `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png`,
  id: req.user.id,
});
});

app.get("/code/preview", async(req, res) => {
res.send(await codeDB.get(`html_code_user.id=${req.user.id}`));
})
app.get("/code/editor2", (req, res) => {
res.render("include/code editor2");
})
app.use("/api/json",  apiRoute);
app.use("/code/api",  CodeApiRoute);
app.use("/panel", PanelRoute);
app.use("/verify/email", EmailVerify);
app.use("/ls/v0",  require("./routes/link shortner v0"));   //v0
app.use("/game",  gameRoute);
io.on('connection', (socket) => {
  socket.req = socket.handshake.session.user
 // console.log('A user connected', socket.req);

socket.on("ping", (callback) => {
    callback(true);
  });
socket.on("data_", () => {
  socket.emit("_data", "Data from RK HOST WS")
})
  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });
});
app.get("/n", (req,res) => {
res.render("n")
});
app.get("/code.editor", checkAuth, async(req,res) => {
res.render("include/code editor", {
id: req.user.id,
})
});
const subscriptions = [];

app.post('/subscribe', (req, res) => {
  const subscription = req.body;
console.log(subscription)
  // Save the subscription to your database or an array
  db.push("noti_array", subscription);

  res.status(201).json({});
});

//app.post('/send-notification', (req, res) => {
function sendN(nameTitle, message, icon) {
  console.log(icon)
  console.log(message)
     var optionss = {
       body: message,
    icon: icon,
    badge: "https://media.discordapp.net/attachments/1083248309289898034/1144861757920268318/20230826_104046.png?width=256&height=256",
    actions: [
        { action: 'reply', title: 'Reply', type: "text" },
      { action: 'close', title: 'Close' },
    ],
                    };
const payload = JSON.stringify({body: message, title: nameTitle, options: optionss});

  // Send the notification to all subscribed clients
   console.log(subscriptions)
     
  db.get("noti_array").forEach(subscription => {
    webPush.sendNotification(subscription, payload)
      .catch(error => {
        console.error('Error sending notification:', error);
      });
  });
}
global.sendN = sendN;

app.get("/offline/notification/send", (req,res) => {
  var ioss = io.of('/chat').sockets
Object.keys(ioss).forEach(uu => {
 uu.emit("ChatMessage_", {
   message: req.params.message
 }) 
});
});
//server not found route
app.get("/server-not-found", (req, res) => {
var name = req.query.name;
  if(name){
    return res.send(`No Server Found Named: ${name} \nPlease Create One first`);
  }
   if(!name){
    res.send(`No Server Found \nPlease Create One first`);
}
})
//logout route
app.get("/logout", (req, res) => {
  res.send("Logout route")
});