const express = require('express');
const router = express.Router();

router.post("/web/code", async(req, res) => {
var code = req.body.code;
  if(!req.user || !req.user.id){
    return res.json({error: "login to save ", command: ["reload"]});
  }
if(!code){
  return res.json({error: "invalid arguments", command: []})
}
  res.json({success: true, error: null, command: [], rest_time: 5000, data_size: "..."})
 await codeDB.set(`html_code_user.id=${req.user.id}`, code);
})

router.get('/web/code', async(req,res) =>{
  if(!req.user || !req.user.id){
     return res.json({error: "login to save ", command: ["reload"]});
  }
  var gotcode = await codeDB.get(`html_code_user.id=${req.user.id}`);
  if (!gotcode) {
    return res.json({success: true, code: '', has: false, command: []});
  }
  res.json({success: true, code: gotcode, has: true, command: []})
})

module.exports = router;
