const express = require('express');
const router = express.Router();
function CheckAuth(req, res, next){
if (!req.user || !req.user.id || !req.user.guilds) {
  return res.redirect(`/login?state=${req.originalUrl}`);
}
next();
};
router.get("/", CheckAuth, async(req, res) => {
  var redi = req.query.rediuri;
  if(!redi) var redi = "/";
  
  if(await mdb.get(`_is_${req.user.id}_email_veryfied_`) !== null){
return res.redirect(redi);
}
  //else

})

    //get otp;

router.post("/verify/:email", CheckAuth, async(req, res) => {
   if(await mdb.get(`_is_${req.user.id}_email_veryfied_`) !== null){
return res.json({success: false, error: "already verified", command: ["reload"]});
   }
  var emailValidRegex = /^[-!#$%&'*+\/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+\/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/;
  var f_email = req.params.email;
  if(emailValidRegex.test(f_email) == false){
    return res.json({success: false, error: "email format doesn't match!", command: ["you shit"]});
  }
  var s_email = req.query.email;
  if(emailValidRegex.test(s_email) == false){
    return res.json({success: false, error: "email format doesn't match!", command: ["you shit"]});
  }
  var t_email = req.body.email;
  if(emailValidRegex.test(t_email) == false){
    return res.json({success: false, error: "email format doesn't match!", command: ["you shit"]});
  }
  if(f_email !== s_email){
    return res.json({success: false, error: "email doesn't match", command: ["you shit"]});
  }
  if(f_email !== t_email){
    return res.json({success: false, error: "email doesn't match", command: ["you shit"]});
  }
  
     var otp = await send_otp(f_email)
  
})




module.exports = router;