const express = require('express');
const router = express.Router();


router.get("/", (req, res) => {
res.send(`<title>Api Router</title><link rel="icon" type="image/png" href="https://cdn.discordapp.com/avatars/1082573970903150633/de5c8eee42a4e61892be37f230275f3e.png"/>

avalable routers:<br>
                            client/status,<br>
                            gen/image?type=*yourType*, <br>
                            bomber/sms?xumber=*phonenumber*&xount=*count || 1*`)
});

router.get("/stats", async(req, res) => {
res.send("STATS WILL SHOWN HERE")
});
router.get(".stats", async(req, res) => {
res.send("STATS WILL SHOWN HERE")
});
router.get("/chat/message/history", async(req, res) => {
//ChatMessageHistory
  let dataToSend = [];
  var rawHistory = db.get("ChatMessageHistory");
  if(!rawHistory){
   res.send([]) 
  }else{
  for(i=0; i<rawHistory.length ; i++){
    var message = rawHistory[i].message;
    var id = rawHistory[i].id;
    if(id == 00000){
          var name = "BOT";
    var avatar = "https://cdn.discordapp.com/attachments/1086602075414204487/1137311903916507206/20230805_143732.png";
      var sentTime = rawHistory[i].timestamp;
    }else{
    var jsonUserData = db.get(`chat_user_data_.uid=${id}`)
    var name = jsonUserData.username;
    var avatar = jsonUserData.avatar;
    var sentTime = rawHistory[i].timestamp;
  }
var finalJson = {
  message: message,
  id: id,
  name: name,
  avatar: avatar,
  bot: rawHistory[i].bot,
  timestamp: sentTime,
}
    dataToSend.push(finalJson)
  }    
res.send(dataToSend)
  }
});

      //profile api
router.get("/profile/user/get", async(req, res) => {
      res.send({status: false, message: "Invalid Params"})
});
router.get("/profile/user/get/:id", async(req, res) => {
  if(req.params.id == 0){
    var finalJson = {
  status: true,
  messageCount: 0,
  id: 0,
  name: "BOT",
  avatar: "",
  description: "A Bot!",
  background_color: '#0eb3eb',
  messages: [],
  server_created: "∞",
  language_known: [0, 1, 2, 3, 4, 5],
}
res.send(finalJson)
  }else{
  var UserData = db.get(`chat_user_data_.uid=${req.params.id}`); 
  if(!UserData){
    res.send({status: false, message: "User Not Found!"});
    return;
  }
var AllMsgArray = db.get(`ChatMessageHistory`);
  if(!AllMsgArray){ var AllMsgArray = []; }
  var UserSendMsg = AllMsgArray.filter(mes => mes.id == req.params.id);
var messages_ = [];
  for(p=0; p<UserSendMsg.length; p++){
    messages_.push(UserSendMsg[p].message)
  } 
var finalJson = {
  status: true,
  messageCount: UserSendMsg.length,
  id: UserSendMsg.id,
  name: UserData.username,
  avatar: UserData.avatar,
  description: "0",
  background_color: '#0eb3eb',
  messages: messages_,
  server_created: 0,
  language_known: [0, 1, 2, 3, 4, 5],
}
res.send(finalJson)
                                          }
});


module.exports = router;

