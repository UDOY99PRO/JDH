const express = require('express');
const router = express.Router();
var app = router;
app.get("/:code", async(req, res) => {
var code = req.params.code;
var link = await mdb.get(`%linksh_$${code}%>redurl`);
let clicks = await mdb.get(`%linksh_$${code}%>clicks`);
if(clicks == null){
   clicks = 0;
}
  if(link){
    res.redirect(link)
    clicks++;
    mdb.set(`%linksh_$${code}%>clicks`, clicks);
    console.log(clicks)
  }else{
    res.send(`<strong>${code}</strong> not found`)
  }
  await mdb.set("%linksh_$test%>redurl", "https://rk-host.uk.to/");
})

module.exports = router;