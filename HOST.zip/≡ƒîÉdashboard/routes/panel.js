const express = require('express');
const router = express.Router();
//random id function
async function makeServerId(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomID = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomID += characters.charAt(randomIndex);
  }
if(JSON.parse(await mdb.get("Server_Used_Ids_")).includes(randomID)){
  return makeServerId(16);
}
  var jsn = JSON.parse(await mdb.get("Server_Used_Ids_"));
  jsn.push(randomID);
await mdb.set("Server_Used_Ids_", `${JSON.stringify(jsn)}`);
  return randomID;
}
//end of the function
   //get access from id
var sharedOrNt = async function(id){
  if(!id) return [];
    var all = await mdb.all();
    var firData = all.filter(i => i.id.startsWith("info_servers_has_"));
    
    // Create an array to store the filtered data
    var filteredData = [];
    
    firData.forEach(i => {
        var data = JSON.parse(i.value).filter(o => o.id == id);
        filteredData = filteredData.concat(data);
    });
    return filteredData;
}
//end
//get all shared daya
var allShared = async function(email){
  if(!email) return [];
    var all = await mdb.all();
    var firData = all.filter(i => i.id.startsWith("info_servers_has_"));
    
    // Create an array to store the filtered data
    var filteredData = [];
    
    firData.forEach(i => {
        var data = JSON.parse(i.value).filter(o => o.access.includes(email));
        filteredData = filteredData.concat(data);
    });
    return filteredData;
    }
//end of all shared data

function CheckAuth(req, res, next){
if (!req.user || !req.user.id || !req.user.guilds) {
  return res.redirect(`/login?state=${req.originalUrl}`);
}
next();
};

router.get("/", CheckAuth, async(req, res) => {

  var ServersList = await mdb.get(`info_servers_has_${req.user.id}_`);
  if(!ServersList){
    var ServersList = [];
  }else{
    var ServersList = JSON.parse(ServersList);
  }
  
  res.render("pages/host/panel list", { req: req, name: req.user.username, avatar: `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png`, id: req.user.id, ServersList: ServersList, sharedServerList: await allShared(req.user.email), mainClient: mainClient });
});

router.get("/shared", CheckAuth, async(req, res) => {
res.json(await allShared(req.user.email))
})
router.get("/shared/:id", CheckAuth, async(req, res) => {
var sharedIsOrNt = await sharedOrNt(req.params.id);
  if(sharedIsOrNt.length == 0){
   return res.json({msg: "not Shared By You"}) 
  }
if(sharedIsOrNt[0].access.includes(req.user.email)){
   res.json(sharedIsOrNt[0])   
  }else{
res.send('no')
  }
})
      //web editor
router.get("/web", CheckAuth, async(req, res) => {
  var ServersList = await mdb.get(`info_servers_has_${req.user.id}_`);
  if(!ServersList){
return res.redirect("/server-not-found?name=web");
  }else{
    if(JSON.parse(ServersList).filter(fff => fff.type == "web").length == 0){
return res.redirect("/server-not-found?name=web");
    }
  }
  res.render("pages/host/web panel", { req: req, name: req.user.username, avatar: `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png`, id: req.user.id, });
})

//create server route
router.post("/create/server", CheckAuth, async(req, res) => {
  var data = req.body;
  var name = data.name.replace(/\ /g, "_");
  var type = data.type;
  var userId = req.user.id;
  if(!data){
    return res.json({success: false, error: "invalid arguments", reload: true});
  }else if(!name){
    return res.json({success: false, error: "name is required!", reload: true});
  }else if(name.split('').length < 3 || name.split('').length > 6){
     return res.json({success: false, error: "name Length error", reload: true});
  }else if(!type){
        return res.json({success: false, error: "type is required!", reload: true});
  }else if(type !== "web" && type !== "bot"){
            return res.json({success: false, error: "type error, doesn't match", reload: true});
  }
if(!(await mdb.get(`info_servers_has_${userId}_`))){
  var UserServerList = [];
}else{
var UserServerList = JSON.parse(await mdb.get(`info_servers_has_${userId}_`));
  }
  if(UserServerList.filter(f => f.type == type).length){
    return res.json({success: false, toast: true, t_type: 2, error: `You Already Have A ${type} Server`, msg: `You Already Have A ${type} Server`, reuse: true});
  }else if(UserServerList.filter(f => f.name.toLowerCase() == name.toLowerCase()).length){
        return res.json({success: false, toast: true, t_type: 2, error: `You Already Have A Server Named ${name}`, msg: `You Already Have A Server Named “${name}”`, reuse: true});
  } //else ↓
     res.json({success: true, toast: true, t_type: 3, error: ``, msg: `Successfully Server Created, type: “${type}”, name: “${name}”`, reload: true});
  
  var dataToSet = {
    name: name,
    type: type,
    url: `/panel/${type}`,
    published: "false", 
    online: true,
    id: await makeServerId(),
    creater_id: req.user.id,
    access: ["sujoyk211@gmail.com"],
    created_at: Date.now()
  };
  console.log(dataToSet)
  var dataToGet = JSON.parse(await mdb.get(`info_servers_has_${req.user.id}_`));
  if(!dataToGet){
   var dataToGet = []; 
  }
dataToGet.push(dataToSet);
var stringifyedFinalData = `${JSON.stringify(dataToGet)}`;
await mdb.set(`info_servers_has_${req.user.id}_`, stringifyedFinalData);
  //end
});
//bot panel
router.get("/bot", CheckAuth, async(req, res) => {
    var ServersList = await mdb.get(`info_servers_has_${req.user.id}_`);
  if(!ServersList){
return res.redirect("/server-not-found?name=bot");
  }else{
    if(JSON.parse(ServersList).filter(fff => fff.type == "bot").length == 0){
return res.redirect("/server-not-found?name=bot");
    }
  }
var botSlotNum = await mdb.get(`get_bot_slot_${req.user.id}=`);
var ownerId = await mdb.get(`${botSlotNum}_get_owner_id_`);

  res.render("pages/host/bot panel", { req: req, name: req.user.username, avatar: `https://cdn.discordapp.com/avatars/${req.user.id}/${req.user.avatar}.png`, id: req.user.id, botSlotNum: botSlotNum, ownerId: ownerId, });
})



module.exports = router;