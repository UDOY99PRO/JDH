module.exports = function(wsServer, io, secret) {
const chatIo = io.of('/chat');
chatIo.use(secret);
  
wsServer.on('connection', (wsocket, req) => {
  console.log(req.session)
  wsocket.on('message', Rawmessage => {
    var message = (Buffer.from(Rawmessage, 'hex').toString('utf8'));
//io.sockets.emit('users_count', 
  });
});

};