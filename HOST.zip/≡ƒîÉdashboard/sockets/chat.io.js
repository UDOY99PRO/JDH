module.exports = async function(io, secret) {
async function makeServerId(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let randomID = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomID += characters.charAt(randomIndex);
  }
if(JSON.parse(await mdb.get("M_Used_Ids_")).includes(randomID)){
  return makeServerId(16);
}
  var jsn = JSON.parse(await mdb.get("Server_Used_Ids_"));
  jsn.push(randomID);
await mdb.set("Server_Used_Ids_", `${JSON.stringify(jsn)}`);
  return randomID;
}
  const chatIo = io.of('/chat');
chatIo.use(secret);
  let connectedUsers = [];
      let disTimeout;
  chatIo.on('connection', (socket) => {

socket.req = socket.handshake.session.user;
    db.set(`chat_user_data_.uid=${socket.req.id}`, {
      username: socket.req.username,
      avatar: `https://cdn.discordapp.com/avatars/${socket.req.id}/${socket.req.avatar}.png`,
           });
    //filter system;;;
    if(!connectedUsers.includes(socket.req.id)){
    connectedUsers.push(socket.req.id);
    socket.broadcast.emit("UserJoined_", {name: (socket.req.username).replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt"), id: socket.req.id,});
      db.push(`ChatMessageHistory`, {
        bot: true,
        id: 0,
        message: `${socket.req.username} Joined The Chat <br> Say Hii To @${socket.req.username}!`,
        timestamp: Date.now(),
      });
      if(db.get("ChatMessageHistory").length > 50){
        var DeleteLastOne = db.get("ChatMessageHistory");
        DeleteLastOne.shift();
        db.set("ChatMessageHistory", DeleteLastOne)
                          }
    };
//ping
socket.on("ping", (callback) => {
    callback(true);
  });
    //on message event
    socket.on("ChatMessage_", async(data, idCallback) => {
      if(!data.message){return;}  
idCallback("hmm ✓✓");
      sendN(socket.req.username, data.message, `https://cdn.discordapp.com/avatars/${socket.req.id}/${socket.req.avatar}.png`)
      var name = (socket.req.username).replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt");
      var avatar = `https://cdn.discordapp.com/avatars/${socket.req.id}/${socket.req.avatar}.png`;
      var id = socket.req.id;
      var message = (data.message).replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt");
socket.broadcast.emit("message_", {
  name: name,
  avatar: avatar,
  message: message,
  id: id,
})
      db.push(`ChatMessageHistory`, {
        bot: false,
        id: id,
        message: message,
        timestamp: Date.now(),
      });
      if(db.get("ChatMessageHistory").length > 50){
        var DeleteLastOne = db.get("ChatMessageHistory");
        DeleteLastOne.shift();
        db.set("ChatMessageHistory", DeleteLastOne)
      }
      var storageSizeInBytes = new TextEncoder().encode(db.get("ChatMessageHistory")).length;

      console.log("size", storageSizeInBytes)
    });

//typing socket
socket.on("iAmTyping_", async() => {
  socket.broadcast.emit("userIsTyping_", {
  name: (socket.req.username).replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt"),
  id: socket.req.id,
})
});                                                                    //disconnedct
socket.on('disconnect', () => {
    disTimeout = setTimeout(() => {
    socket.broadcast.emit("UserLeft_", {name: (socket.req.username).replace(/&/g, "&amp").replace(/</g, "&lt").replace(/>/g, "&gt"), id: socket.req.id,});
      db.push(`ChatMessageHistory`, {
        bot: true,
        id: 0,
        message: `${socket.req.username} Left The Chat!`,
        timestamp: Date.now(),
      });
            if(db.get("ChatMessageHistory").length > 50){
        var DeleteLastOne = db.get("ChatMessageHistory");
        DeleteLastOne.shift();
        db.set("ChatMessageHistory", DeleteLastOne)
            }
   connectedUsers = connectedUsers.filter(usr => usr !== socket.req.id);   
  disTimeout = null;
        console.log(connectedUsers) 
    }, 7000); 
});
    //if user returns;

    if(disTimeout){
  if(connectedUsers.includes(socket.req.id)){ 
   clearTimeout(disTimeout)
      distimeout = null;
  }
    }  
  console.log(connectedUsers)                
                                          });

//db.delete("ChatMessageHistory")
//keys
/** 
messageStore: content: message.content, isImage?: --, ifImage { url: link }, id: author.id
*/

        /** 
        Greater-than sign (>): &gt;
Less-than sign (<): &lt;
Ampersand (&)
        */

function sendMessageNoti(msg){
  var allUsers = io.sockets.sockets;
  allUsers.forEach(u => u.emit("ChatMessage_", msg));
}

global.sendMessageNoti = sendMessageNoti;

};