const express = require('express');
const webPush = require('web-push');

const app = express();
app.use(express.json());

const publicKey = 'your-public-key'; // Your VAPID public key
const privateKey = 'your-private-key'; // Your VAPID private key
webPush.setVapidDetails('mailto:your-email@example.com', publicKey, privateKey);

app.post('/subscribe', (req, res) => {
  const subscription = req.body.subscription;

  // Save the subscription in your database

  res.status(201).json({});
});

app.post('/send-notification', (req, res) => {
  const subscription = req.body.subscription;
  const payload = JSON.stringify({ text: 'Hello, this is a push notification!' });

  webPush.sendNotification(subscription, payload)
    .then(() => {
      res.status(200).json({});
    })
    .catch(error => {
      console.error('Error sending notification:', error);
      res.status(500).json({ error: 'Failed to send notification' });
    });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
