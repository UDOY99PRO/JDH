fs.readFile('code_main_.js', 'utf8', function(err, data){ 
fs.appendFile(`./clients/client${db.get("total_slot_")+1}.js`, " \n" + data.replace("what_the_num", db.get("total_slot_")+1), function (err) {
 // if (err) throw err;
  console.log('Saved!');
});
})