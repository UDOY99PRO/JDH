 let number = 0;
async function start(token, status_text, a_type, a_status, ownerId, SLOT) {
     const lg = mainClient.guilds.cache.get('1082201967054565406');
   
  const lc = lg.channels.cache.find(c => c.id === '1111975011142610984');

  number++;
  var Slot_Num = SLOT;
  var token = token;
//  console.log(token)
  async function get_owner_(id) {
    if (id == ownerId || mdb.get(`get_devloper_id_`)) {
      return true;
    } else { return false; }
  }

  var text_status = status_text,
    activity_type = a_type,
    activity_status = a_status;

  if (activity_type == null) var activity_type = 0;
  if (text_status == null) var text_status = "🇮🇳 | RK HOST | 🇮🇳";
  if (activity_status == null) var activity_status = 'idle';

  const client = new Discord.Client({
    fetchAllMembers: true,
    restTimeOffset: 0,
    failIfNotExists: false,
    shards: "auto",
    shardCount: 5,
    allowedMentions: {
      parse: ["roles", "users"],
      repliedUser: true,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER', 'MANAGE_MESSAGE', 'DIRECT_MESSAGE', Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction],
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
  });
client.Slot_Num = Slot_Num;
  client.on("ready", (c) => {

    client.commands = new Discord.Collection();
    client.aliases = new Discord.Collection();

    console.log(` \n✓ TEMP CLIENT STARTED ${number} `.blue.bold);
lc.send({content: `✓ TEMP CLIENT STARTED ${number} `})
    lc.send({content: `<@852183674203144226>\n https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=534723950656&scope=bot`})
    const activities = { name: text_status, type: activity_type };

    client.user.setActivity(activities)
    
setTimeout(() => {
    client.user.setStatus(activity_status)
}, 5000);
    // promotion
    var actiArray = [
      { name: text_status, type: activity_type },
                    { name: "🇮🇳 | RK HOST | 🇮🇳", type: 0 }
    ];
    let i = 0;
    setInterval(() => {
      if (i >= actiArray.length) i = 0
      client.user.setActivity(actiArray[i])
      i++;
    }, 15000);

    fs.readdirSync('./clients event').forEach((event) => {
      require(`../clients event/${event}`)(client)
    });
  })


  client.login(token).catch(e => {
    console.log("failed to start temp client 😢 number: " + number)
    lc.send({content: `failed to start temp client 😢 number: ${number}`});
  });
  

}
global.OnlineBot = start;

