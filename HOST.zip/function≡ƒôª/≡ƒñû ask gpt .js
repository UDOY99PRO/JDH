/*var axios = require("axios");
async function ask_gpt(ques){
//  return null
  var response = await axios.post('https://chat.chatgptdemo.net/chat_api_stream', {
  question: ques,
  chat_id: process.env.gptid,
  timestamp: Date.now(),
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoia2UzZjBna3V5ZmF5ZnQ2NHYiLCJleHAiOjE2ODg0NzY2NzUuOTIwMTMxNH0.9I36DdefBYPzWHmG46J--QnRE_SML3nEinBiWe0B_Cw"
}, {
  headers: {
    'Content-Type': 'application/json'
  }
})

  let text = await ' ';
await response.data.split(/(\r\n|\r|\n){2}/g).forEach(async k =>{
  let dataString = await k.replace("data: ", "");
  return dataString;*?*/
 /* try{
  var k = (JSON.parse(dataString))
    if(k.choices[0].delta.content){
    //  console.log(k.choices[0].delta.content)
            text = text + k.choices[0].delta.content;
    }
    if(k.choices[0].finish_reason !== null){
return text;
//console.log(text);
    }
// console.log(k)
  }
  catch{}*/
   //                                   })
/*
.then(async response => {
  let text = ' ';
((response.data).split(/(\r\n|\r|\n){2}/g)).forEach(k =>{
  let dataString = k.replace("data: ", "");
  try{
  var k = (JSON.parse(dataString))
    if(k.choices[0].delta.content){
    //  console.log(k.choices[0].delta.content)
            text = text + k.choices[0].delta.content;
    }
    if(k.choices[0].finish_reason !== null){
return text;
//console.log(text);
    }
// console.log(k)
  }
  catch{}
                                      })
})
.catch(error => {
  console.error(error);
});*/
//}

//global.ask_gpt = ask_gpt;