
module.exports = {
  name: "prefix",
  aliases: ["change-prefix"],
  execute: async (client, message, args) => {
    var prefix = await mdb.get(`get:guild_${message.guild.id}:_prefix_${client.Slot_Num}_`);
   
    if(prefix == null){
      
       var prefix = await mdb.get(`get_prefix_${client.Slot_Num}_`);
  if(prefix == null) var prefix = '?';
      
    }
    
if(!args[0]){
  
  var get_prefix = new Discord.EmbedBuilder()
  .setColor(color.yellow).setTitle("Prefix For This Server")
  .setDescription(`Your Prefix For this server is ${prefix} \nTo change this prefix give a prefix with the command => Ex: ${prefix}prefix new`)
  .setFooter({text: `prefix is ${prefix}`})
  .setTimestamp(); 
  return message.reply({embeds: [get_prefix]});
  
}

if(args[0]){
  
  mdb.set(`get:guild_${message.guild.id}:_prefix_${client.Slot_Num}_`, args[0]);
  var new_prefix = new Discord.EmbedBuilder()
  .setColor(color.green).setTitle(`${emoji.tick} | Prefix Changed Successfully | ${emoji.tick}`)
  .setDescription(`${emoji.tick} successfully Changed the prefix for this server \n\nOld prefix: ${prefix} \nNew prefix: ${args[0]} `)
  .setFooter({text: `Bye Bye ${prefix} `})
  .setTimestamp();
 return message.reply({embeds: [new_prefix]})
}
  }
}
