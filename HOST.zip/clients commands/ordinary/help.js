module.exports = {
  name: "help",
  aliases: ["h"],
  execute: async (client, message, args) => {
    var prefix = await mdb.get(`get:guild_${message.guild.id}:_prefix_${client.Slot_Num}_`);
   
    if(prefix == null){
      
       var prefix = await mdb.get(`get_prefix_${client.Slot_Num}_`);
  if(prefix == null) var prefix = '?';
      
    }
    
    message.react(emoji.tick).catch({});
var mbed = new Discord.EmbedBuilder()
    .setColor(color.cyan)
    .setTitle("Help Menu")
    .setDescription(`**___COMMANDS___**
${prefix}help
${prefix}say 
${prefix}announce
${prefix}kick
${prefix}ban
${prefix}timeout`)
    .setFooter({text: "Help Menu"})
    .setTimestamp()
    message.reply({embeds: [mbed]})
  }
}
