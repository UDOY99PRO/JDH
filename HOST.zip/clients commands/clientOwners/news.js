var Discord = require("discord.js");
module.exports = {
  name: "news",
  aliases: ["rk-news", "rk-get-news", "get-news"],
  execute: async (client, message, args) => {
    await mdb.set(`RK_HOST_NEWS`, "Test news")
var news = await mdb.get(`RK_HOST_NEWS`);
    if(!news || news == null){
      return message.reply("No news is available now!")
    }

    var em_news = new Discord.EmbedBuilder().setColor(color.yellow).setTitle("NEWS FROM RK HOST")
    .setDescription(`<%%News%%>`).setFooter({text: `published on: <%%pub_date%%>`})
    message.reply({embeds: [em_news]}).then(m => {
    m.react(emoji.tick)  
    });

  }};