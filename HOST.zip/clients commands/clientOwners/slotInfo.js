var Discord = require("discord.js");
module.exports = {
  name: "slot-info",
  aliases: ["slot", "info-slot"],
  execute: async (client, message, args) => {
var IfOwner =  client.get_owner_;
    var NoPerm = new Discord.EmbedBuilder().setColor(color.red).setTitle(`${emoji.error} Access Denied! `).setDescription(`You cant use this command!`).setFooter({text: `Bot Hosted by Rk Host`}).setTimestamp()
   
    if(await IfOwner(message.author.id) == false){
      return message.reply({embeds: [NoPerm]})
    }
var Slot_Num = client.Slot_Num;
    var slotEm = new Discord.EmbedBuilder()
    .setColor(color.cyan).setTitle("Slot Info")
    .setFooter({text: rkID})
    .setTimestamp()
    .setDescription(`\`\`\`\nSlot Id: #${Slot_Num}\nOnline: true\nSlot Error: no error\nThis Bot is Hosting in slot Id #${Slot_Num} on Rk Host\`\`\``);
message.reply({embeds: [slotEm]})

  }};