module.exports = async(client) => {
setTimeout(async() => {

let guild = mainClient.guilds.cache.get('1082201967054565406');
  let owner = await mdb.get(`${client.Slot_Num}_get_owner_id_`);
if (!guild.members.cache.has(owner)) {
var email = await mdb.get(`_is_${owner}_email_veryfied_`);
  if(email !== null){
    db.add("killed_slot_", 1);
    client.destroy()
    
  console.log("not have in rrkk:   " + email + " : " + client.Slot_Num)  
  }

}
}, 5000);
};

//Killed Bots: ∞  [Bcs Bot's Owner left This Guild]