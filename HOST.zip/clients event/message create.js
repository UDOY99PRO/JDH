module.exports = (client) => {
  client.on('messageCreate', message => {
    if(message.content.startsWith('hii')){
message.react("👋")
 }
  })
}