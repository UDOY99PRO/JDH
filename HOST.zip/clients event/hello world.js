module.exports= async(client) => {
    var em = new Discord.EmbedBuilder()
.setColor(color.green).setTitle(`I am Online ${client.user.username}`).setTimestamp();
    await report_wh([em])
};