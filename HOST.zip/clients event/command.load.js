module.exports = (client) =>{
  var Discord = require("discord.js");
  const {readdirSync} = require('fs');
const ascii = require('ascii-table')
let table = new ascii("Commands");
  var colors = require ("colors");
//const db  = require("quick.db")
  var num = 0;
  var ok = [];
  var er = [];
table.setBorder("|", "=", "|", "|",)
table.setHeading('Command', ' Load status');

    readdirSync('./clients commands/').forEach(dir => {
    
        const commands = readdirSync(`./clients commands/${dir}/`).filter(file => file.endsWith('.js'));
        for(let file of commands){
          num++;
            let pull = require(`../clients commands/${dir}/${file}`);
          
            if(pull.name){
                client.commands.set(pull.name, pull);
              ok.push(file.replace(".js", ''))      
                table.addRow(file.replace(".js", ''), '✓ Ok')
            } else {
              er.push(file.replace(".js", ''))     
              table.addRow(file.replace(".js", ''), 'Error')
                continue;
            }
          if(pull.aliases && Array.isArray(pull.aliases)) pull.aliases.forEach(alias => client.aliases.set(alias, pull.name))
        }
    });

    console.log(table.toString().rainbow.bold);
  }