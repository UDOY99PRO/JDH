const { Schema, model } = require("mongoose");

const test = new Schema({
  id: String,
  value: String,
});

module.exports = {
  test: model("test", test),
};