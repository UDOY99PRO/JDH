const mongoose = require("mongoose"); //,
//colors = require("colors");
mongoose.set('strictQuery', false);
 var johai =  mongoose.connect(process.env["MONGO"], {
  useNewUrlParser: true,
  useUnifiedTopology: true,
 }).then(async (a, b) => {
     console.log(`Connected MongoDB`.bold.brightCyan);
     global.mongo_conn = true;
    console.log(a.serverConfig)
    //(db.serverConfig.isConnected())
  }).catch((err) => {

    })
/*
johai.on('open', (a) => {
  console.log(`Connected MongoDB`.bold.brightCyan);
     global.mongo_conn = true;
    console.log(johai.serverConfig)
    //(db.serverConfig.isConnected())
})
johai.on('error', (err) => {
 global.mongo_conn = false;
   console.log(err)
})*/
