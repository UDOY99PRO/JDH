var mdb = require("./db");
var mongoose = require("mongoose");
var pinG;
var lastPingFetched = Date.now();
module.exports = {

async set(key, val) {
  if(!key || !val){ return `provide a ${key? "value" : "key" }`}
  if(val == Array){
return "Array";
  }
  
             await mdb?.test?.updateOne({ id: key }, {
                $set: {
                  value: val
                }
              }, { upsert: true }).catch(e => { console.log(e)}
)
  return true;
},

  async get(key) {
  if(!key){
    return `provide a key`
  }
     var r = await mdb?.test?.findOne({ id: key })

if(r == null){  return null;  }else{ return r.value }
  },

  async all() {
  
     var r = await mdb?.test?.find()

if(r == null){  return null;  }else{ return r }
  },

  async delete(key) {
 //  await mdb?.test?.deleteMany()
     var r = await mdb?.test?.findOne({ id:key });
    if(r == null) return `${key} not found`;
await mdb?.test.deleteOne({ id: key })
   
    return true;
    
  },

  async deleteAll(pass) {
    if(pass == "db"){
await mdb?.test?.deleteMany()
return true;
    }else{
      return false;
    }
  },

  async ping() {
    if(lastPingFetched + 1000*60*15 < Date.now()){
   var lastPingFetched = Date.now();
    var db = mongoose.connection.db;
  var startTime = Date.now();
  var result = await db.command({ ping: 1 });
  var latency = Date.now() - startTime; 
    var pinG = latency;
  return latency;
  }else{
      return pinG;
    }
      
},
 async uptime() {
    try {
      const adminDb = mongoose.connection.db.admin();
      const serverStatus = await adminDb.serverStatus();
      const uptimeInSeconds = serverStatus.uptime;
 return uptimeInSeconds*1000;
    /*  const uptimeInHours = uptimeInSeconds / 3600;

      return uptimeInHours.toFixed(2);*/
    } catch (error) {
      console.error("Error fetching MongoDB server status:", error);
      return null;
    }
  }

}
