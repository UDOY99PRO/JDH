const { Schema, model } = require("mongoose");
var dbnamw = require("./connect.html.code.db.js");
const html_code = new Schema({
  id: String,
  value: String,
});

module.exports = {
  html: dbnamw.model("html", html_code),
}