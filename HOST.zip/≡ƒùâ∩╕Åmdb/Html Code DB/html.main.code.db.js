var cdb = require("./html.db.js");
var mongoose = require("mongoose");
module.exports = {

  
async set(key, val) {
  if(!key || !val){ return `provide a ${key? "value" : "key" }`}
  if(val == Array){
return "Array";
  }
  
             await cdb?.html?.updateOne({ id: key }, {
                $set: {
                  value: val
                }
              }, { upsert: true }).catch(e => { console.log(e)}
)
  return true;
},

  async get(key) {
  if(!key){
    return `provide a key`
  }
     var r = await cdb?.html?.findOne({ id: key })

if(r == null){  return null;  }else{ return r.value }
  },

  async all() {
  
     var r = await cdb?.html?.find()

if(r == null){  return null;  }else{ return r }
  },

  async delete(key) {
 //  await cdb?.html?.deleteMany()
     var r = await cdb?.html?.findOne({ id:key });
    if(r == null) return `${key} not found`;
await cdb?.html.deleteOne({ id: key })
   
    return true;
    
  },

  async deleteAll(pass) {
    if(pass == "db"){
await cdb?.html?.deleteMany()
return true;
    }else{
      return false;
    }
  },

  async ping() {
  const db = mongoose.connection.db;
  const startTime = Date.now();
  const result = await db.command({ ping: 1 });
  const latency = Date.now() - startTime; 
  return latency;
},
 async uptime() {
    try {
      const adminDb = mongoose.connection.db.admin();
      const serverStatus = await adminDb.serverStatus();
      const uptimeInSeconds = serverStatus.uptime;
 return uptimeInSeconds*1000;
    /*  const uptimeInHours = uptimeInSeconds / 3600;

      return uptimeInHours.toFixed(2);*/
    } catch (error) {
      console.error("Error fetching MongoDB server status:", error);
      return null;
    }
  }

}