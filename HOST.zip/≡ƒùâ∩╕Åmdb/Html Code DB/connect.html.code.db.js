const mongoose = require("mongoose"); //,
//colors = require("colors");
mongoose.set('strictQuery', false);
  var comodb = mongoose.createConnection(process.env["CODE_MONGO"], {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  })/*.then(async (a, b) => {
     console.log(`Connected MongoDB For Getting Codes`.bold.brightCyan);
   //  global.mongo_conn = true;
  //  console.log(a.serverConfig)
    //(db.serverConfig.isConnected())
  }).catch((err) => {
 //global.mongo_conn = false;
   console.log(err)
    })*/

comodb.on('open', () => {
     console.log(`Connected MongoDB For Getting Codes`.bold.brightCyan);
});

comodb.on('error', (err) => {
  console.error('Error connecting to MongoDB:', err);
});

module.exports = comodb;