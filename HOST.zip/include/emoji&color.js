module.exports = {
  color: {
    red: "#f20000",
    green: "#72fc00",
    cyan: "#00fcdf",
    yellow: "#f4fc00",
    purple: "#fc00f0",
    pink: "#fc0394",
    blue: "#00f0f0",
    black: "#000000",
    white: "#ffffff",
    random: "Random",
    r: "Random"
  },
  emoji: {
    id: {
      tick: "1055007437498884127",
      cross: "1029971406710116362",
      error: "1029971406710116362",
      success: "1055007437498884127",
      warning: "1056839782598201364",
      info: "1056840478718447676",
      question: "1056840518484623412",
      down: "1056492013861732442",
      up: "1056491835025014805",
      devloper: "1056841177355276288",
      playing: "1061919416566173696"

    },
    html: {
  tick: "https://cdn.discordapp.com/emojis/1055007437498884127.gif",
  cross: "https://cdn.discordapp.com/emojis/1029971406710116362.gif",
  error: "https://cdn.discordapp.com/emojis/1029971406710116362.gif",
  success: "https://cdn.discordapp.com/emojis/1055007437498884127.gif",
  warning: "https://cdn.discordapp.com/emojis/1056839782598201364.gif",
  info: "https://cdn.discordapp.com/emojis/1056840478718447676.gif",
  question: "https://cdn.discordapp.com/emojis/1056840518484623412.gif",
  down: "https://cdn.discordapp.com/emojis/1056492013861732442.gif",
  up: "https://cdn.discordapp.com/emojis/1056491835025014805.gif",
  devloper: "https://cdn.discordapp.com/emojis/1056841177355276288.gif",
  playing: "https://cdn.discordapp.com/emojis/1061919416566173696.gif"
},

    tick: "<a:rk_tick:1085878653793083512>",
    cross: "<a:rk_cross:1085878343964041316>",
    error: "<a:rk_cross:1085878343964041316>",
    success: "<a:rk_tick:1085878653793083512>",
    warning: "<a:ultra_warning:1056839782598201364>",
    info: "<a:ultra_info:1056840478718447676>",
    question: "<a:ultra_question:1056840518484623412>",
    down: "<a:ultra_down:1056492013861732442>",
    up: "<a:rk_up:1085877968594804757>",
    devloper: "<a:rk_devloper:1085878779852881920>",
    wifi: "<a:ultra_ping:1056488003893219429>",
    ram: "<a:ultra_ram:1056862031464116244>", 
    playing: "<a:ultra_playing:1061919416566173696>",
    announce: "<a:rk_announce:1085878186157551707>",
    bot: "<a:rk_robot:1086254900012404746>",
    loading: "<a:rk_loading:1087594960171319386>"
  }
    }