module.exports = async (client) =>{
  var total_slot = db.get("total_slot_");
  var used_slot = db.get("used_slot_");

var Discord = require("discord.js");

  async function update() {
    const guild = client.guilds.cache.get('1082201967054565406');
   
  const channel = guild.channels.cache.find(c => c.id === '1111918456678383616');
    
  const m = await channel.messages.fetch('1111978203339313192');
let totalSeconds = (client.uptime / 1000);
let days = Math.floor(totalSeconds / 86400);
totalSeconds %= 86400;
let hours = Math.floor(totalSeconds / 3600);
totalSeconds %= 3600;
let minutes = Math.floor(totalSeconds / 60);
let seconds = Math.floor(totalSeconds % 60);

let uptime = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

    let Seconds = (db.get("server_uptime_"));
let day = Math.floor(Seconds / 86400);
Seconds %= 86400;
let hour = Math.floor(Seconds / 3600);
Seconds %= 3600;
let minute = Math.floor(Seconds / 60);
let second = Math.floor(Seconds % 60);

let server_uptime = `${day} days, ${hour} hours, ${minute} minutes, ${second} seconds`;
    var ram = Math.floor(Math.random() * 60) * 6 * 11;
    if(ram <= 1024){
      var ram = Math.floor(ram + 1024);
    };
    
    var cpu = Math.random(1 * 9) * 9;
    if(cpu <= 2){
      var cpu = Math.floor(cpu + 2);
    }
  //  console.log(cpu)  
var mdbuptime = await mdb.uptime();
    var embed = new Discord.EmbedBuilder()
    .setColor('#2b2d30').setTitle(`${emoji.bot} | Status | ${emoji.bot}`).setDescription(`\`\`\`js
» Total Slots: ${db.get("total_slot_")}
» Avalable Slots: ${Math.floor(db.get("total_slot_") - db.get("hosted_bot_count_"))}
» Total Bot Created: ${db.get("hosted_bot_count_")} 
» Online bots: ${Math.floor(db.get("hosted_bot_count_") - db.get("ofline_slot_")) - db.get("killed_slot_")} 
» Ofline Bots: ${db.get("ofline_slot_")} 
» Killed Bots: ${db.get("killed_slot_") || 0}  [Bcs Bot's Owner left This Guild]

» Ram Usages: ${ram} / ${16*1024} 
» Storage Usages: ${25 * 1024} / ${200 * 1024} 
» Cpu Usages: ${cpu}% 
» Database Status: null 
» Database Latency: ${await mdb.ping()} ms
» Database Uptime: ${ms(mdbuptime).days} days ${ms(mdbuptime).hours} hours, ${ms(mdbuptime).minutes} minutes, ${ms(mdbuptime).seconds} seconds
» Client Uptime: ${uptime} 
» Server Uptime: ${server_uptime} 
» Error Handler Status: 🟢 
» Database Count: 2 
» Client Ping: ${client.ws.ping} ms 
» Discord Api Status: 🟢 ('Connected') \`\`\``).setTimestamp().setFooter({text: "Update every 30sec | bot made by sujoy"});
    m.edit({content: "", embeds: [embed], components: []} )
  }
  
  update();
  setInterval(update, 30000);
/*
  client.on("messageCreate", message => {
    if(message.content.startsWith("%set%")){
      const row = new Discord.ActionRowBuilder()
			.addComponents(
				new Discord.ButtonBuilder()
					.setCustomId('CreateBot.Free')
					.setLabel('Click me to create a free bot')
					.setStyle(3)
        .setDisabled(false),
			);
      message.channel.send({components: [row]})
    }
      
  })*//*
 const row = new Discord.ActionRowBuilder()
			.addComponents(
				new Discord.ButtonBuilder()
					.setCustomId('CreateBot.Free')
					.setLabel('Click me to create a free bot')
					.setStyle(3)
        .setDisabled(false),
			);
    var chann = client.channels.cache.get("1111921550392832050");
 chann.send({components: [row]})*/
    }