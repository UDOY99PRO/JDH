module.exports = async(client) => {
//1126048012599308368
    client.on("messageCreate", async(message) => {
          if(message.channel.id == "1126048012599308368"){
    if(message.author.bot){
     return; //i hate bots !!
    }
       //     return "oho";
 var ques = message.content;
      var ans = await ask_gpt(ques)
      message.reply(`${ans}`)
      console.log(ans)
    }
  });

}