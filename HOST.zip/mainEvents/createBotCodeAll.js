module.exports = async (client) => {
       const lg = client.guilds.cache.get('1082201967054565406');
   var canPID = "1112227460159914085";
  var donePID = "1112227390635114639";
  const lc = lg.channels.cache.find(c => c.id === '1111975011142610984');

  var ruleEmbed = new Discord.EmbedBuilder()
  .setColor(color.yellow)
  .setTitle("RULES")
  .setDescription(`1 » If you leave the server your bot will go **offline** and you will be **permanently banned**\n 2 » If you take advantage of any glitch, you will be **permanently banned** If there is a glitch then create a ticket\n »»⟩ if you faced any type of glitch/error/problem or if you have any question then you can make a ticket   \n\n **If you break any of the above rules, you will be permanently banned from RK Host**  \n For more Rules Check Rules channel ✓`)
.setFooter({text: `READ THE RULES ELSE ☠️`, iconURL: client.user.avatarURL()});


  var token_embed = new Discord.EmbedBuilder().setColor(color.cyan).setTitle(`${emoji.loading} | Send Token`)
  .setDescription(`Send your bots Token by clickng the button 👇 below`)
  .setFooter({text: `⌛ you have  60 sec to responce.`})
  .setTimestamp()
    var check_c = new Discord.Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
      });

  
async function makeBotFree(i) {
  client.bot_process_running.set(`_${i.user.id}_`, i.user.id)
var guild = i.guild;
var channel = await guild.channels.create({
    name: `${i.user.username}`,
    type: Discord.ChannelType.GuildText,
  permissionOverwrites: [
		{
			id: i.guild.id,
			deny: [Discord.PermissionsBitField.Flags.ViewChannel],
		},
		{
			id: i.user.id,
			allow: [Discord.PermissionsBitField.Flags.ViewChannel, Discord.PermissionsBitField.Flags.ReadMessageHistory, Discord.PermissionsBitField.Flags.AttachFiles, Discord.PermissionsBitField.Flags.EmbedLinks, Discord.PermissionsBitField.Flags.SendMessages],
    },
	],
    // your permission overwrites or other options here
}).then(async c =>{ 
  await c.setParent('1112218588154171534')
    await i.editReply({content: `your process for creating the  bot will be done in <#${c.id}>`})
 /**/   let ss_token = ''
  let id = ''
  let three = ''
  let four = ''
  let five = ''
  let status = ''
/** / */  let activity_status = ''
    /** / */ let activity_status_send = ''
 /** / */ let presience_status = ''
    /**/ let presience_status_send = ''
  /**/ let activity_text = ''
  /**/ let prefix_text = ''

  var embed = new Discord.EmbedBuilder().setColor(color.cyan).setTitle(`${emoji.loading} | Waiting...`)
  .setDescription(`Are you ready? \nSay **yes** to start the process and **no** to cancle the process!`)
  .setFooter({text: `Reply in 30 sec.`})
  .setTimestamp()
    var bala = await c.send({content: `<@${i.user.id}>`, embeds: [embed] })
        const filter = m => m.author.id === i.user.id
  async function get_response() { 
await bala.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] })
			.then(async collected => {

  if(collected.first().content.toLowerCase() == 'cancel' || collected.first().content.toLowerCase() == 'no' || collected.first().content.toLowerCase() == 'n'){
    status = 1
              client.bot_process_running.delete(`_${i.user.id}_`)
    await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
    c.setName(`cancelled_${i.user.username}`)
    return
  }else if(collected.first().content.toLowerCase() == 'yes' || collected.first().content.toLowerCase() == 'n'){
collected.first().delete();
    await bala.edit({embeds: [token_embed]})
}else{
    status = 1
    bala.channel.send(`${collected.first().content} is not a valid reply`)
        }
        
			})
			.catch(async (collected, e) => {
        
                  client.bot_process_running.delete(`_${i.user.id}_`)
        
await bala.edit({content: `<@${i.user.id}> try again`, embeds: [] });
        bala.channel.send(`<@${i.user.id}> got no response from you!`)
         c.setName(`cancelled_${i.user.username}`)
        status = 1
        return 
			});
  };
//emb of get responce
  
  async function get_token() {
    const btn_filter = f => {
      if(f.user.id === i.user.id) return true;
    return interaction.reply({content: `${emoji.error} | this button is not for you`, ephemeral: true});

};
    var btnrow = new Discord.ActionRowBuilder()
			.addComponents(
				new Discord.ButtonBuilder()
					.setCustomId('GetToken')
					.setLabel('Click me to send token secretly')
					.setStyle(3),
			);
var next_bala = await bala.reply({components: [btnrow]})
await next_bala.awaitMessageComponent({ btn_filter, componentType: Discord.ComponentType.Button, time: 60000 })
    .then(async collected => {

var modal = new Discord.ModalBuilder()
  .setCustomId(`token_submit`)
  .setTitle(`Send Your Token secretly `)

      const token_input = new Discord.TextInputBuilder()
			.setCustomId('tOkEn')
		    // The label is the prompt the user sees for this input
			.setLabel("paste yout bot token here ↓")
		    // Short means only a single line of text
			.setStyle(Discord.TextInputStyle.Paragraph)
      .setRequired(true);
	var tokenActionRow = new Discord.ActionRowBuilder().addComponents(token_input);
      modal.addComponents(tokenActionRow);
      await collected.showModal(modal)
 var submitted = await collected.awaitModalSubmit({
btn_filter,
  time: 60000,
}).catch(error => {
  console.error(error)
  return null
})

if(submitted) {
 await next_bala.delete()
  var submttkn = await submitted.fields.getTextInputValue('tOkEn');

  await check_c.login(submttkn).catch(async(e) => {
await console.log(`${e}`)
  status = 1

    await bala.channel.send({content: `${emoji.error} | An Invalid Token Was provided ! <@${submitted.user.id}>!!!!\n\n ** Create a ticket for more information **`})
   await c.setName(`Invalid_Tkn_${i.user.username}`)
    return;
  })
  
if(status) return;

	ss_token = submttkn;
  await submitted.reply({
    content: `✓ Successfully token collected safely🔒`, ephemeral: true
  })
  check_c.destroy();

      }
    })
    .catch(async collected => {

        client.bot_process_running.delete(`_${i.user.id}_`)
        
await bala.edit({content: `<@${i.user.id}> try again`, embeds: [] });
        await bala.channel.send(`<@${i.user.id}> got no response from you!`)
         await c.setName(`cancelled_${i.user.username}`)
        status = 1
    
        return 
                              })
//bala.reply({})
  }
//end of get_token
  var ooh = new Discord.EmbedBuilder()
    .setColor(color.yellow)
    .setTitle(`${emoji.loading} | select your bot  presience status`)
    .setDescription(`Select by clicking the menu below`)
    .setFooter({text: `You have 60 sec`})
    .setTimestamp();
    var pre_row = new Discord.ActionRowBuilder()
			.addComponents(
				new Discord.StringSelectMenuBuilder()
					.setCustomId('Presience_set')
					.setPlaceholder('click to select')
					.setMinValues(1)
					.setMaxValues(1)
					.addOptions([
						{
							label: '🟢 | ONLINE',
							description: 'Set\'s the bot status to online [🟢]',
							value: 'ONLINE',
						},
						{
							label: '🌙 | IDLE',
							description: 'Set\'s the bot status to idle [🌙]',
							value: 'IDLE',
						},
						{
							label: '⛔ | DND',
							description: 'Set\'s the bot status to dnd [⛔]',
							value: 'DND',
						},
					]),
			);
  
  async function get_presince_status() {
    
    var presince = await bala.edit({embeds: [ooh], components: [pre_row]})
var stringselectfilter = f =>{
if(f.user.id === i.user.id) return true;
    return;
}
await presince.awaitMessageComponent({ stringselectfilter, componentType: Discord.ComponentType.StringSelect, time: 60000 })
	.then(async interaction =>{
presience_status = (interaction.values[0]).toLowerCase();
    presience_status_send = interaction.values[0];
    await interaction.reply({content: `You selected ${interaction.values[0]} For your bot's presience status`, ephemeral: true})
       await pre_row.components[0].setDisabled(true)
  await bala.edit({embeds: [ooh], components: [pre_row]})
  }
    )
	.catch(async err => {
    status = 1
    await pre_row.components[0].setDisabled(true)
    await bala.edit({embeds: [ooh], components: [pre_row]})
    await bala.channel.send("No reply after 60 sec")
c.setName(`cancelled_${i.user.username}`)
    return;
  });
  }
  //end of get_presince_status

var opoh = new Discord.EmbedBuilder()
    .setColor(color.yellow)
    .setTitle(`${emoji.loading} | select your bot's activity status`)
    .setDescription(`Select by clicking the menu below`)
    .setFooter({text: `You have 60 sec`})
    .setTimestamp();
    var act_row = new Discord.ActionRowBuilder()
			.addComponents(
				new Discord.StringSelectMenuBuilder()
					.setCustomId('activity_set')
					.setPlaceholder('click to select')
					.setMinValues(1)
					.setMaxValues(1)
					.addOptions([
						{
							label: '🎮 | PLAYING',
							description: 'Set\'s the bot\'s Activity status to playing [🎮]',
							value: 'PLAYING',
						},
						{
							label: '👀 | WATCHING',
							description: 'Set\'s the bot\'s Activity status to watching [👀]',
							value: 'WATCHING',
						},
						{
							label: '👂 | LISTNING',
							description: 'Set\'s the bot\'s Activity status to listning [👂]',
							value: 'LISTNING',
						},
					]),
			);
   
async function get_activity_status() {
    
    var presince = await bala.edit({embeds: [opoh], components: [act_row]})
var stringselectfilter = f =>{
if(f.user.id === i.user.id) return true;
    return;
}

await presince.awaitMessageComponent({ stringselectfilter, componentType: Discord.ComponentType.StringSelect, time: 60000 })
	.then(async interaction =>{
    activity_status_send = interaction.values[0];
    
    if(interaction.values[0] == "PLAYING"){
   activity_status = 0;   
    }else if(interaction.values[0] == "WATCHING"){
activity_status = 3;
    }else if(interaction.values[0] == "LISTNING"){
      activity_status = 2;
    }
//BASTI KA HASTI 😂
    await interaction.reply({content: `You selected ${interaction.values[0]} status for your bot`, ephemeral: true})
      await act_row.components[0].setDisabled(true)
  await bala.edit({embeds: [opoh], components: [act_row]})
  }
    )
	.catch(async err => {
    status = 1
    await act_row.components[0].setDisabled(true)
    await bala.edit({embeds: [opoh], components: [act_row]})
   await bala.channel.send("No reply after 60 sec")
    await c.setName(`cancelled_${i.user.username}`)
    return;
  });
              }
  //end of activity status

  async function get_activity_text() {
    var letme = new Discord.EmbedBuilder()
.setColor(color.yellow)
  .setTitle(`${emoji.loading} | Send your bots Avtivity text`)
  .setDescription(`Let me know what you want your bot's activity text to be
  Like: ${activity_status_send} **???**
  * Dont send Playing, Watching, Listning..   just send the text✓`)
.setFooter({text: `⌛ 60 sec only`})
  .setTimestamp();
    await bala.edit({ embeds: [letme], components: []})
    await bala.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] })
			.then(async collected => {
        activity_text = collected.first().content
        collected.first().delete();
        await bala.channel.send({content: `Your bot's activity is set to ${activity_status_send} ${collected.first().content} `}).then(m => {
     setTimeout(() => {
       m.delete();
     }, 3000);    
        });

      }).catch(async (e) => {
        console.log(e)
        client.bot_process_running.delete(`_${i.user.id}_`)
        
await bala.edit({content: `<@${i.user.id}> try again`, embeds: [] });
        bala.channel.send(`<@${i.user.id}> got no response from you!`)
         c.setName(`cancelled_${i.user.username}`)
        status = 1
        return 
      })
  }
  //end activity text collector
  async function get_prefix_text() {
    var letmepre = new Discord.EmbedBuilder()
.setColor(color.yellow)
  .setTitle(`${emoji.loading} | Send your bots Default prefix`)
  .setDescription(`Let me know what you want your bot's default ___**prefix**___ to be
  Like: . , ! ? & $ % * # @ + - © ® ; • ~ = >
> You can set whatever you want as the bot's default prefix`)
.setFooter({text: `⌛ 60 sec only`})
  .setTimestamp();
    await bala.edit({ embeds: [letmepre], components: []})
    await bala.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] })
			.then(async collected => {
        prefix_text = ((collected.first().content).slice().trim().split(/ +/g))[0];
        collected.first().delete()
        
        await bala.channel.send({content: `${((collected.first().content).slice().trim().split(/ +/g))[0]} is set to your bot's default prefix`}).then(m => {
     setTimeout(() => {
       m.delete();
     }, 3000);   
        });

      }).catch(async (e) => {
        console.log(e)
        client.bot_process_running.delete(`_${i.user.id}_`)
        
await bala.edit({content: `<@${i.user.id}> try again`, embeds: [] });
        bala.channel.send(`<@${i.user.id}> got no response from you!`)
         c.setName(`cancelled_${i.user.username}`)
        status = 1
        return 
      })
    }
async function final_setup(){
      if(Math.floor(db.get("total_slot_") - db.get("hosted_bot_count_")) == 0){
       await bala.channel.send(`${emoji.error} | all slots are full! sorry'!`)
        var no_ava = new Discord.EmbedBuilder()
.setColor(color.red)
        .setTitle(emoji.error + "Error")
.setDescription(`No Available slot found \n\n Any doubt? fell free to create a ticket`)
        .setFooter({text: `Try again after some time`})
.setTimestamp();
        await bala.edit({embeds: [no_ava]})
        await c.setParent(canPID)
        c.setName(`Slot_err_${i.user.username}`).catch({});
      } else {
        //setup main
        var tknTosend = (ss_token.replace(/[a-z]/g, '•')).replace(/[A-Z]/g, "*")
        let symbol;
        if(presience_status == "online"){
symbol = '🟢'
}else if(presience_status == "idle"){
          symbol = "🌙"
}else if(presience_status == "dnd"){
          symbol = "⛔"
}
var lastEmb = new Discord.EmbedBuilder()
.setColor(color.green) 
.setTitle(emoji.tick + "all done ✓")
        .setDescription(`\`\`\`\nBot Token => ${tknTosend}\n Bot Prefix => ${prefix_text}\n Bot Presience => ${presience_status_send} [${symbol}]\n Bot Status => ${activity_status_send} ${activity_text} \n\n Your Bot Is Hosting On Slot No #${db.get("hosted_bot_count_") + 1} \n\n*Create A ticket if you faced any problem \`\`\``)
        .setFooter({ text: `Your bot is online Now 🎉`})
        .setTimestamp();
await bala.edit({embeds: [lastEmb]});
        await c.setParent(donePID)
        bala.channel.send({content: `<@${i.user.id}>`, embeds: [ruleEmbed]}).then(m => {
          m.react(emoji.tick)
        });
        
        //text_status_get_
db.add("hosted_bot_count_", 1)
        var slot__num = db.get("hosted_bot_count_");
        await mdb.set(`get_prefix_${slot__num}_`, prefix_text)
        await mdb.set(`get_bot_slot_${i.user.id}=`, slot__num)
    console.log(await mdb.get(`get_bot_slot_${i.user.id}=`));
        
        await mdb.set(`activity_status_get_${slot__num}_`, presience_status)
        await mdb.set(`activity_type_get_${slot__num}_`, activity_status)
       await mdb.set(`text_status_get_${slot__num}_`, activity_text)
      await mdb.set(`${slot__num}_get_owner_id_`, i.user.id)
        await mdb.set(`token_slot_${slot__num}_get_`, ss_token)

        OnlineBot(ss_token, activity_text, activity_status, presience_status, i.user.id, slot__num); 
//token, status_text, a_type, a_status        
c.setName(`Done_${i.user.username}`).catch({});
        //hosted_bot_count_ + 1
        //log channel
var toLog = new Discord.EmbedBuilder()
.setColor(color.green) 
.setTitle(emoji.tick + "all done ✓")
        .setDescription(`\`\`\`\nBot Token => ${tknTosend}\n Bot Prefix => ${prefix_text}\n Bot Presience => ${presience_status_send} [${symbol}]\n Bot Status => ${activity_status_send} ${activity_text} \n\n Bot Is Hosting On Slot No #${db.get("hosted_bot_count_")} \n\nCreater: ${i.user.tag}\n id: ${i.user.id} \`\`\``)
        .setFooter({ text: `Started ...`})
        .setTimestamp();
        lc.send({embeds: [toLog]});
      }
}
//end of text set
async function aurek() {
await get_response()
  if(status){
    client.bot_process_running.delete(`_${i.user.id}_`)
    await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
     c.setName(`cancelled_${i.user.username}`)
      await c.setParent(canPID)
    return;
  }
await get_token()
  if(status){
      client.bot_process_running.delete(`_${i.user.id}_`)
    await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
    await c.setParent(canPID)
    
        return;
      }
await get_presince_status()
  if(status){
      client.bot_process_running.delete(`_${i.user.id}_`)
   // await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
    await c.setParent(canPID)
        return;
      }
await get_activity_status()
  if(status){
      client.bot_process_running.delete(`_${i.user.id}_`)
await c.setParent(canPID)
   // await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
        return;
  }
 await get_activity_text()
  if(status){
      client.bot_process_running.delete(`_${i.user.id}_`)
   // await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
    await c.setParent(canPID)
        return;
        }
   await get_prefix_text()
  if(status){
      client.bot_process_running.delete(`_${i.user.id}_`)
   // await bala.edit({content: `Process Cancelled By ${i.user.username}`, embeds: []})
    await c.setParent(canPID)
        return;
              }
  
  await final_setup()  //**//
}
  aurek()

  //khatam yes collector


      




  



  


      /*  await setTimeout(() =>{
          c.delete()
          client.bot_process_running.delete(i.user.id)
        }, 5000);*/
            })
  



  
}
  global.makeBotFree = makeBotFree;
  
}

/*async function part1(){
        await message.channel.send(`>>> ${client.config.giveawayEmoji} Please mention the channel that the giveaway should be in.\nEnter \`cancel\` to cancel.`)
        await message.channel.awaitMessages(m => m.author.id == message.author.id,
        {max: 1, time: 1800000}).then(collected => {
            if (collected.first().content.toLowerCase() == 'cancel') {
                message.channel.send('**Command Canceled**')
                status = 1
                return
            }else{
                giveawayChannel = collected.first().mentions.channels.first()
            if(!giveawayChannel){
                message.reply('No channel was mentioned\nPlease try again.')
              
            }}
        }).catch(() => {
            message.reply('No answer after 30 minutes, please try the command again.');
            status = 1
    })
                 }*/
/**interaction.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] })
			.then(collected => {
				interaction.followUp(`${collected.first().author} got the correct answer!`);
			})
			.catch(collected => {
				interaction.followUp('Looks like nobody got the answer this time.');
			});*/


/*
const client = new Client({
    fetchAllMembers: true,
    restTimeOffset: 0,
    failIfNotExists: false,
    shards: "auto",
    shardCount: 5,
    allowedMentions: {
      parse: ["roles", "users"],
      repliedUser: true,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER', 'MANAGE_MESSAGE', 'DIRECT_MESSAGE', Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction],
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
  });
*/




/**
const btn_filter = i => {
	i.deferUpdate();
	return i.user.id === interaction.user.id;
};

message.awaitMessageComponent({ filter, componentType: Discord.ComponentType.Button, time: 60000 })
	.then(interaction => interaction.editReply(`You selected ${interaction.values.join(', ')}!`))
	.catch(err => console.log('No interactions were collected.'));*/