module.exports = async(client) => {
const { ActionRowBuilder, Events, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

/*
  client.on("messageCreate", async(message) => {
    if(message.author.bot) return; //i hate bots !!
  if(message.content.startsWith("+-test")){
    const row = new ActionRowBuilder()
			.addComponents(
				new StringSelectMenuBuilder()
					.setCustomId('select')
					.setPlaceholder('Nothing selected')
					.setMinValues(1)
					.setMaxValues(1)
					.addOptions([
						{
							label: 'Select me',
							description: 'This is a description',
							value: 'first_option',
						},
						{
							label: 'You can select me too',
							description: 'This is also a description',
							value: 'second_option',
						},
						{
							label: 'I am also an option',
							description: 'This is a description as well',
							value: 'third_option',
						},
					]),
			);

	var me = await message.reply({ content: 'testing...', components: [row] });

    const collector = me.createMessageComponentCollector({ filter: (i) => i.isStringSelectMenu() && i.user && i.message.author.id == client.user.id, time: 30000 });

    collector.on("collect", async(collected) => {
      if(!collected.isStringSelectMenu()) return;
const modal = new Discord.ModalBuilder()
  .setCustomId(`test_modal`)
  .setTitle(`test`)

      const favoriteColorInput = new TextInputBuilder()
			.setCustomId('favoriteColorInput')
		    // The label is the prompt the user sees for this input
			.setLabel("What's your favorite color?")
		    // Short means only a single line of text
			.setStyle(TextInputStyle.Short);

		const hobbiesInput = new TextInputBuilder()
			.setCustomId('hobbiesInput')
			.setLabel("What's some of your favorite hobbies?")
		    // Paragraph means multiple lines of text.
			.setStyle(TextInputStyle.Paragraph);

		// An action row only holds one text input,
		// so you need one action row per text input.
		const firstActionRow = new ActionRowBuilder().addComponents(favoriteColorInput);
		const secondActionRow = new ActionRowBuilder().addComponents(hobbiesInput);

		// Add inputs to the modal
		modal.addComponents(firstActionRow, secondActionRow);


await collected.showModal(modal)
      const submitted = await collected.awaitModalSubmit({

  time: 60000,
  filter: i => i.user.id === i.user.id,
}).catch(error => {
  console.error(error)
  return null
})

if (submitted) {
 
  await submitted.reply({
    content: `Your age is , and your name is . Hi!`
  })
        }
    })
    collector.on("end", async col =>{
      row.components[0].setDisabled(true)
      await me.edit({ content: 'Completed', components: [row] })
    })
  }


    
})*/


}
/*const completion = await openai.createChatCompletion({
  model: "gpt-3.5-turbo",
  messages: messages,
});*/