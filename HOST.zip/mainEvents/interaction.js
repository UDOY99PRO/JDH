;module.exports = async(client) => {
  var disabled = false;
  var { Discord, Events, EmbedBuilder, ButtonBuilder, ActionRowBuilder } = require("discord.js");
  async function check(interaction) {
    var haikenahi = client.exist.get(`_exist_${interaction.userId}_`)
    if(haikenahi >= Date.now()){
      return true;
    //  return interaction.editReply(`${emoji.error} | <@${interaction.userId}> slow down!! Try again after 5 to 10 sec`).catch({});
    }else{ 
          client.exist.set(`_exist_${interaction.userId}_`, Math.floor(Date.now() + 5000))
      return false; }
    
  }
//async function update() {
  client.on(`Update_Embed_`, async()=>{
  var embed = new EmbedBuilder()
     .setColor("#2b2d30")
.setTitle(`${emoji.bot} | Bot Maker Panel | ${emoji.bot}`)
     .setDescription(`Make Bot without Code
     
Click the button below to make your own bot

You need only  a bot Account if you dont have a bot account [click here](https://discord.com/developers/applications) to make one  

Total bot created: ${db.get("hosted_bot_count_")}
Total Click in this button: ${db.get("create_bot_button_clicked")}

Total Email Verified user: ${db.get(`total_email_verified_`)}`)
     .setFooter({text: "🇮🇳 Host | Free host"});
  var bhjd = false;
const row = new ActionRowBuilder()
			.addComponents(
				new ButtonBuilder()
					.setCustomId('CreateBot.Free')
					.setLabel('Click me to create a free bot')
					.setStyle(3)
        .setDisabled(false),
			);
  

  var chann = client.channels.cache.get("1111921550392832050");
// chann.send("Panel")
    var mes = await chann.messages.fetch("1111980052888952984");
  await mes.edit({embeds: [embed], components: [row]});
  });

client.on(Events.InteractionCreate, async(interaction) => {
      if(!interaction.isButton()) return;
  if(interaction.customId !== 'CreateBot.Free') return;  
  
//update()
 //   client.emit("Update_Embed_");
    await interaction.deferReply({ ephemeral: true }).catch({});
  var iop = await check(interaction);
   if(iop == true){
     await interaction.editReply(`${emoji.error} | <@${interaction.user.id}> too many clicks by users Try again after 5 to 10 sec`);
     return;
   }
  if(disabled == true){
  await interaction.editReply(`${emoji.error} | <@${interaction.user.id}> currently create#bot function is disable talk with devloper for more details`);
    return;
  }
  var has_bot = await mdb.get(`get_bot_slot_${interaction.user.id}=`)
  if(has_bot !== null){
    return interaction.editReply(`You already have a bot :) \nYou can't host more then 1 bot in free service!`)
  }
  
  var running_bot_making = client.bot_process_running.get(`_${interaction.user.id}_`);
  console.log(running_bot_making)
  if(running_bot_making !== undefined){
    return interaction.editReply(`${interaction.user} already your bot making process is running..`)
  }
  db.add("create_bot_button_clicked", 1);
  client.emit("Update_Embed_");
  
    var veryfied_or_nt = await mdb.get(`_is_${interaction.user.id}_email_veryfied_`);

    if(veryfied_or_nt == null){
      var access = new EmbedBuilder()
.setColor(color.red)
.setTitle(`${emoji.error} | Verify your email first`)
.setDescription(`Click Verify Button to verify your email`)
.setFooter({text: `need veryfication!`})
.setTimestamp()
      
      const eve = new ActionRowBuilder()
			.addComponents(
        			new ButtonBuilder()
					.setCustomId('veryfy:email')
					.setLabel('📧 | verify your email')
					.setStyle(1)
        .setDisabled(false),
			);
      
return await interaction.editReply({embeds: [access], ephemeral: true, components: [eve]}).catch({});
    }
    
    if(Math.floor(db.get("total_slot_") - db.get("hosted_bot_count_")) == 0){
   await interaction.editReply({content: "No Slots are Available To host your bot Please try after some time and tell the owners to make more slots", ephemeral: true})
//update();
      return;
    }


   makeBotFree(interaction)
//update();
  });



client.on(Events.InteractionCreate, async(interaction) => {
      if(!interaction.isButton()) return;
  if(interaction.customId !== 'veryfy:email') return; 
 await interaction.deferReply({ephemeral: true})
var ooe = await check(interaction);
   if(ooe == true){
     await interaction.reply(`${emoji.error} | <@${interaction.user.id}> too many clicks by users Try again after 5 to 10 sec`).catch(async() => {
          await interaction.editReply(`${emoji.error} | <@${interaction.user.id}> too many clicks by users Try again after 5 to 10 sec`)  
     }).catch({})
     return;
     }


  var veryfied = await mdb.get(`_is_${interaction.user.id}_email_veryfied_`);
  if(veryfied !== null){
    return interaction.editReply({content: `${emoji.success} | ${interaction.user} You are already a Verified User \n\n Your email: ${veryfied}`, ephemeral: true})
  }
  var veryfy_running = await client.veryfication_process_running.get(`_if_veryfy_running_${interaction.user.id}_`);
if(veryfy_running == true){
  return interaction.editReply({content: `<@${interaction.user.id}> Check your Dm !  Already a verification process is running!;`, embeds: []}).catch(async() => {
    return interaction.reply({content: `<@${interaction.user.id}> Check your Dm !  Already a verification process is running!;`, embeds: []})
  })
}

client.veryfication_process_running.set(`_if_veryfy_running_${interaction.user.id}_`, true)
  
  var newemb = new EmbedBuilder().setColor(color.yellow)
  .setTitle(`${emoji.loading} | Need Email Address!`)
  .setDescription(`Send me your Email address to verify`)
  .setFooter({text: `You have 60 sec to send`})
  .setTimestamp()
  
  interaction.user.send({embeds: [newemb]}).then((m) => {
    interaction.editReply({content: `${interaction.user} check your dm or click <#${m.channel.id}>`, ephemeral: true})
   const filter = m => m.author.id === interaction.user.id

        var collector = m.channel.createMessageCollector({
            filter,
            time: 60000,
            max: 1,
            maxProcessed: 1,
            errors: ['time']
        })
    
collector.on('collect', async collected => {
  var cont = collected.content;
  let emailregex = /^[-!#$%&'*+\/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+\/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/;
var real = emailregex.test(cont);
  if(real == false){
    var fal = new EmbedBuilder().setColor(color.red)
    .setTitle(`${emoji.error} | Invalid Email!`)
    .setDescription(`> \`${cont}\` is not a valid email address try again..`)
.setFooter({text: `Try again..!!`}).setTimestamp()
    m.channel.send({embeds: [fal]})
    collected.react(emoji.error)
   return collector.stop('invalid_');
  }
  collected.react(emoji.success)
   var otp = await send_otp(cont)
    console.log(otp)
  var sendi = new EmbedBuilder().setColor(color.cyan)
  .setTitle(`${emoji.success} | successfully otp sent`)
  .setDescription(`Otp sent to your email`)
  .setFooter({text: `wait for 5 sec`})
  .setTimestamp()
 var em = await m.channel.send({embeds: [sendi]})
  await delay(5000);

var emb = new EmbedBuilder().setColor(color.green)
  .setTitle(`${emoji.loading} | OTP?`)
  .setDescription(`> Send the OTP which is sent to your ema¡l`)
  .setFooter({text: "You have 60 sec"})
  .setTimestamp();
 await em.edit({embeds: [emb]}).then(om => {
    var otpfilter = m => m.author.id === interaction.user.id

        var ocollector = om.channel.createMessageCollector({
            otpfilter,
            time: 60000,
            max: 1,
            maxProcessed: 1,
            errors: ['time']
        })
var inv = new EmbedBuilder().setColor(color.red)
  .setTitle(`${emoji.error} | wrong 0TP !`)
  .setDescription(`> wrong  0TP !!..`)
  .setFooter({text: "Try again 😊"})
  .setTimestamp();
  var rig = new EmbedBuilder().setColor(color.green)
  .setTitle(`${emoji.tick} | Verified `)
  .setDescription(`> Successfully You are verified \n\nNow you can create your bot ;) \n\n\`${cont} i like it\``)
  .setFooter({text: "Verified ✓"})
  .setTimestamp();
ocollector.on("collect", async mes => {

  if(mes.content !== otp){
    mes.react(emoji.error)
    client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`);
    ocollector.stop('invalid_');
    return mes.channel.send({embeds: [inv]})
    
  }
  mes.react(emoji.tick)
mes.channel.send({embeds: [rig]})
await mdb.set(`_is_${interaction.user.id}_email_veryfied_`, cont)
  db.add(`total_email_verified_`, 1)
ocollector.stop('done_'); 
  client.emit("Update_Embed_");
})
    ocollector.on("end", async (mes, reason) => {
      var notp = new EmbedBuilder().setColor(color.red)
      .setTitle(`${emoji.error} | Time Up!`)
      .setDescription(`> You didn't provide me the otp on time :!`)
      .setFooter({text: 'Try again ..!..'})
      .setTimestamp();
      
     if(reason == 'time'){
       await client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`)
       return om.edit({embeds: [notp]})
     }else if(reason == 'invalid_'){
       await client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`)
return;
     }else if(reason == 'done_'){
       await client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`)
       return;
     }
 
    })

    
  })
  
})
collector.on('end', async (error, reason) => {
  var noemail = new EmbedBuilder().setColor(color.red)
  .setTitle(`${emoji.error} | Where is Email?`)
  .setDescription(`> you didn't provide me an email ..!..`)
  .setFooter({text: "try again_ .. hehe !"})
  .setTimestamp();
 
  if(reason == 'time'){
    client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`)
    return m.edit({embeds: [noemail]})
  }else if(reason == 'invalid_'){
    return client.veryfication_process_running.delete(`_if_veryfy_running_${interaction.user.id}_`)
  }
})

  });
       });
       
/*if((await mdb.get(`_is_852863168841908295_email_veryfied_`)) !== null){
await mdb.delete(`_is_852863168841908295_email_veryfied_`)

  db.subtract(`total_email_verified_`, 1)
}*/

}
          
