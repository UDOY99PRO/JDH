var fs = require("fs");
module.exports = async(client) => {
/*let nnum = 0;
fs.readFile('code_main_.js', 'utf8', function(err, data){ 
setInterval(() => {
  fs.appendFile(`./test/client${db.get("total_slot_")+1+nnum}.js`, " \n" + data.replace("what_the_num", db.get("total_slot_")+1+nnum), function (err) {
 // if (err) throw err;
  console.log('Saved!');
nnum++
});
}, 5000);
}); */
};