async function main() {
  var ms = require("./function📦/ms.js");

  global.ms = ms;
// console.log(process.env.REPLIT_DB_URL)
  async function report_wh(em, icon) {
        const { WebhookClient } = require('discord.js');

const webhookClient = new WebhookClient({ url: process.env["report_wh"] });
webhookClient.send({
	username: 'Report Log',
	avatarURL: icon,
	embeds: em,
}).catch({});
  }
global.report_wh = report_wh;
  
  require("./error.handler.js");
  
const nodemailer = require("nodemailer");
var include = require("./include/emoji&color.js");
  console.log(include)
  
  global.color = include.color;
  global.emoji = include.emoji;

  var fs = require("fs");
  global.fs = fs;

  function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
  }

global.wait = sleep;
global.delay = sleep;
function make_otp() {

  var digits = '192837465564738291'; 

    let OTP = ''; 

    for (let i = 0; i < 6; i++ ) { 

        OTP += digits[Math.floor(Math.random() * 10)]; 

    } 
  return OTP;
}

async function send_otp(email){
  var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env['rkemailid'],
    pass: process.env['rkemailpass']
  }
});
var otp = make_otp()
  
  var mailOptions = {
  from: process.env[`rkemailid`],
  to: email,
  subject: `OTP for Email veryfication is ${otp}`,
html: `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>OTP Verification</title></head><body style="font-family: Arial, sans-serif; text-align: center; padding: 20px;"><h1>OTP Verification</h1><p>Your One-Time Password (OTP) for verification is:</p><div style="background-color: #f5f5f5; padding: 10px 20px; border-radius: 5px; font-size: 24px;">${otp}</div><p>Please use this OTP to verify your Email:</p><p>If you did not request this OTP, please ignore this email.</p></body></html>`
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
});
  return otp;
}

  global.send_otp = send_otp;

  global.colors = require("colors");
  console.log("Starting The Host:...🚨".bold.brightMagenta)
  require("./🗃️mdb/connect_js.js");
  global.mdb = require("./🗃️mdb/main.js");
  global.codeDB =  require('./🗃️mdb/Html Code DB/html.main.code.db')
  var fs = require("node:fs");
  global.db = require("quick.db");
  const Database = require("@replit/database");
global.rdb = new Database();
var ask_gpt = require("./function📦/🤖 ask gpt .cs");
 global.ask_gpt = ask_gpt;
require('./function📦/random.cpp');
  global.discord = require("discord.js");

  var { GatewayIntentBits, Partials, Client, Events } = require("discord.js"); 
  global.GatewayIntentBits = GatewayIntentBits;
  global.Partials = Partials;
  global.Events = Events;
  global.Discord = require("discord.js");
  require("./🌐dashboard/index.js");
  const client = new Client({
    fetchAllMembers: true,
    restTimeOffset: 0,
    failIfNotExists: false,
    shards: "auto",
    shardCount: 5,
    allowedMentions: {
      parse: ["roles", "users"],
      repliedUser: true,
    },
    partials: ['MESSAGE', 'CHANNEL', 'REACTION', 'GUILD_MEMBER', 'USER', 'MANAGE_MESSAGE', 'DIRECT_MESSAGE', Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction],
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.GuildMessageReactions,
      GatewayIntentBits.GuildPresences,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildVoiceStates
    ]
  });
var slot_avalable_number_ = db.get(`avalable_slot_number_`);
  global.mainClient = client;
  client.login(process.env[`t`])
  client.on("ready", async (c) => {
    client.commands = new Discord.Collection();
    client.exist = new Map();
    client.bot_process_running = new Map();
    client.veryfication_process_running = new Map();
global.serverIcon = client.guilds.cache.get("1082201967054565406").iconURL();
  // ?? client.user.setAvatar(serverIcon);
    console.log(`Login as ${c.user.username}`.green);
var login_ = new Discord.EmbedBuilder().setColor(color.green).setTitle(`Login Log`).setDescription(`___**${client.user.username} is now Online :)**___`).setFooter({text: `id: null`, iconURL: serverIcon}).setTimestamp().setThumbnail(serverIcon);
    report_wh([login_], serverIcon)
    var inclu = new Discord.EmbedBuilder().setColor(color.green).setDescription(`\`\`\`js\n${require('util').inspect(include)}\`\`\``)
    report_wh([inclu], serverIcon)
    client.user.setStatus(db.get("Bot_Status_"));
     
    const activities = [
      { name: ` 🇮🇳 RK HOST 24/7 🎉`, type: 0 }, // LISTENING
      { name: ` 🇮🇳 RK HOST 24/7 💯`, type: 0 }, // PLAYING
      { name: ` 🇮🇳 RK HOST 24/7 🔥`, type: 0 }, // LISTENING
      { name: ` 🇮🇳 RK HOST 24/7 ⭐`, type: 0 }, // PLAYING
      { name: ` 🇮🇳 RK HOST 24/7 💖`, type: 0 }, // LISTENING
      { name: ` 🇮🇳 RK HOST 24/7 🌟`, type: 0 }, // PLAYING
    ];
    const status = [
      'idle',
      'dnd'
    ];
    let i = 0;
    setInterval(() => {
      if (i >= activities.length) i = 0
      client.user.setActivity(activities[i])
      i++;
    }, 8000);

    let s = 0;
    setInterval(() => {
      if (s >= activities.length) s = 0
      client.user.setStatus(status[s])
      s++;
    }, 60000);

require("./function📦/OnlineBot.js");
    db.set("total_slot_", 0);
    db.set("ofline_slot_", 0);
    db.set("hosted_bot_count_", 0);
    db.set("killed_slot_", 0)


   /* fs.readdirSync('./clients').forEach(async(cli) => {
      await delay(1000);
      require(`./clients/${cli}`)
     return db.add("total_slot_", 1);
    // await delay(1000)
    });*/

    function add_uptime_server() {
      db.add("server_uptime_", 1);
    }
    setInterval(add_uptime_server, 1000);
//commands and events
fs.readdirSync('./mainEvents').forEach((event) => {
      require(`./mainEvents/${event}`)(client)
    });
  })
  var emails = (await mdb.all()).filter(i => String(i.id).endsWith("_email_veryfied_"))//.then(e => console.log(e.length));
/*var emails = (await mdb.all()).filter(i => String(i.id).endsWith("_email_veryfied_"));
  */emails.forEach(e => console.log(e.value));
  

//** mdb.delete("_is_852183674203144226_email_veryfied_");


//console.log(mutualGuilds);
  /*setInterval(async() => {
  console.log(await mdb.ping());
    console.log(`${ms(await mdb.uptime()).days} : ${ms(await mdb.uptime()).hours} : ${ms(await mdb.uptime()).minutes} : ${ms(await mdb.uptime()).seconds}`);
  }, 1000);*/
 // db.delete("noti_array")

  /*  await mdb.delete("info_servers_has_852183674203144226_", `${JSON.stringify([])}`);*/
           //  console.log(await ask_gpt("hii"))
   var allClientFilesArray = fs.readdirSync('./clients')/*.forEach(async(cli) => {
      console.log(cli)
      await delay(1000);
      require(`./clients/${cli}`)
     return db.add("total_slot_", 1);
    // await delay(1000)
    });*/
    for(let i = 0; i < allClientFilesArray.length; i++) {
     setTimeout(() => {
   console.log(` running ${allClientFilesArray[i]}`)
  require(`./clients/${allClientFilesArray[i]}`)
     return db.add("total_slot_", 1);
     }, i * 3000);
    }

}
main()

/** 
bin": {
    "test": "/cmd.js"
  },
  */
