const mutualGuilds = client.guilds.cache.filter(async (guild) => {
   return guild.members.cache.has(await mdb.get(`get_devloper_id_`));
});

    // This will log the mutual guild(s) the bot and the author is in, of course you can change it however you'd like.
  var ttttt = mutualGuilds.forEach(gg => {
  var gh = gg.id;
    if(gh === "1082201967054565406"){ console.log("yes")
                                  } else {
console.log('no')
    }

    })